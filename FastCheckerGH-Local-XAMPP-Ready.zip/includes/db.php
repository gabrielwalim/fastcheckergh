<?php

require_once __DIR__ . '/security.php';
fc_configure_error_reporting();
fc_security_headers();

$host = getenv("DB_HOST") ?: "localhost";
$dbname = getenv("DB_NAME") ?: "fastcheckergh";
$username = getenv("DB_USER") ?: "root";
$password = getenv("DB_PASSWORD");
if ($password === false) {
    $password = getenv("DB_PASS") ?: "";
}

try {
    $pdo = new PDO(
        "mysql:host=$host;dbname=$dbname;charset=utf8mb4",
        $username,
        $password,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
} catch (PDOException $e) {
    error_log("FastCheckerGH database connection failed: " . $e->getMessage());
    throw $e;
}
