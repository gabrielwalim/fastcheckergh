<?php
/**
 * FastCheckerGH shared public footer.
 *
 * Existing routes confirmed in this project:
 * Home             -> index.php
 * BECE             -> bece.php
 * WASSCE           -> wassce.php
 * Automatic Results-> automatic-results.php
 * Retrieve         -> retrieve.php
 * My Checkers      -> my-checkers.php
 * Contact          -> index.php#contact
 *
 * Privacy Policy and Terms of Service pages do not currently exist in the
 * project, so they are rendered as non-clickable placeholders rather than
 * pointing to invented/broken URLs.
 *
 * Social URLs are placeholders because no existing social media URLs were
 * found in the project. Replace the href="#" values when the real URLs are
 * available.
 */
?>
<footer class="fc-footer">
    <div class="fc-footer-shell">
        <div class="fc-footer-main">
            <div class="fc-footer-brand">
                <a class="fc-footer-logo" href="index.php" aria-label="FastCheckerGH home">
                    <span class="fc-footer-logo-fast">Fast</span><span class="fc-footer-logo-checker">Checker</span><span class="fc-footer-logo-gh">GH</span>
                </a>
                <p>Your trusted partner for BECE and WASSCE<br>result checking in Ghana.</p>
            </div>

            <nav class="fc-footer-nav" aria-label="Footer navigation">
                <a href="index.php">Home</a>
                <a href="bece.php">BECE</a>
                <a href="wassce.php">WASSCE</a>
                <a href="automatic-results.php">Automatic Results</a>
                <a href="retrieve.php">Retrieve</a>
                <a href="my-checkers.php">My Checkers</a>
            </nav>

            <!-- Social URLs are placeholders (#). Replace these with the official profile URLs. -->
            <div class="fc-footer-social" aria-label="Social media">
                <a href="#" class="fc-footer-social-link" aria-label="Facebook" data-placeholder-social="true">
                    <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M14.2 8.1h2.2V4.6c-.4-.1-1.6-.2-3-.2-3 0-5.1 1.8-5.1 5.3v2.9H5v3.9h3.3v7.9h4v-7.9h3.3l.5-3.9h-3.8V10c0-1.1.3-1.9 1.9-1.9Z"/></svg>
                </a>
                <a href="#" class="fc-footer-social-link" aria-label="X / Twitter" data-placeholder-social="true">
                    <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5.4 4.2h4.2l3.5 5 4.2-5h1.3l-4.9 5.9 5.9 9.7h-4.2l-3.8-5.7-4.7 5.7H5.6l5.5-6.6-5.7-9Zm2.8 1.5 7.6 12.5h1.8L9.9 5.7H8.2Z"/></svg>
                </a>
                <a href="#" class="fc-footer-social-link" aria-label="Instagram" data-placeholder-social="true">
                    <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7.3 3.5h9.4A3.8 3.8 0 0 1 20.5 7v10a3.8 3.8 0 0 1-3.8 3.5H7.3A3.8 3.8 0 0 1 3.5 17V7a3.8 3.8 0 0 1 3.8-3.5Zm0 1.7A2.1 2.1 0 0 0 5.2 7.3v9.4a2.1 2.1 0 0 0 2.1 2.1h9.4a2.1 2.1 0 0 0 2.1-2.1V7.3a2.1 2.1 0 0 0-2.1-2.1H7.3Zm9.9 1.3a1 1 0 1 1 0 2 1 1 0 0 1 0-2ZM12 7.2A4.8 4.8 0 1 1 7.2 12 4.8 4.8 0 0 1 12 7.2Zm0 1.7A3.1 3.1 0 1 0 15.1 12 3.1 3.1 0 0 0 12 8.9Z"/></svg>
                </a>
                <a href="#" class="fc-footer-social-link" aria-label="YouTube" data-placeholder-social="true">
                    <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20.2 7.1a2.7 2.7 0 0 0-1.9-1.9C16.6 4.7 12 4.7 12 4.7s-4.6 0-6.3.5a2.7 2.7 0 0 0-1.9 1.9C3.3 8.7 3.3 12 3.3 12s0 3.3.5 4.9a2.7 2.7 0 0 0 1.9 1.9c1.7.5 6.3.5 6.3.5s4.6 0 6.3-.5a2.7 2.7 0 0 0 1.9-1.9c.5-1.6.5-4.9.5-4.9s0-3.3-.5-4.9ZM10 15.2V8.8l5.5 3.2-5.5 3.2Z"/></svg>
                </a>
            </div>
        </div>

        <div class="fc-footer-bottom">
            <nav class="fc-footer-secondary" aria-label="Legal and support navigation">
                <!-- These pages do not exist in the current project; keep them non-clickable until routes are created. -->
                <span class="fc-footer-disabled" title="Privacy Policy page not available">Privacy Policy</span>
                <span class="fc-footer-separator" aria-hidden="true">|</span>
                <span class="fc-footer-disabled" title="Terms of Service page not available">Terms of Service</span>
                <span class="fc-footer-separator" aria-hidden="true">|</span>
                <a href="index.php#contact">Contact</a>
            </nav>
            <p class="fc-footer-copyright">© <?php echo date('Y'); ?> FastCheckerGH. All rights reserved.</p>
        </div>
    </div>
</footer>
