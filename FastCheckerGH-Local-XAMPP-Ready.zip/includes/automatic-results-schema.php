<?php
/**
 * FastCheckerGH automatic-results schema bootstrap.
 *
 * This bootstrap is intentionally defensive because older FastCheckerGH
 * databases may already contain a result_requests table from an earlier
 * version of the feature.
 */
require_once __DIR__ . '/db.php';

function fc_table_exists(PDO $pdo, string $table): bool
{
    $st = $pdo->prepare("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = ?");
    $st->execute([$table]);
    return (int)$st->fetchColumn() > 0;
}

function fc_column_exists(PDO $pdo, string $table, string $column): bool
{
    $st = $pdo->prepare("SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = ? AND column_name = ?");
    $st->execute([$table, $column]);
    return (int)$st->fetchColumn() > 0;
}

function fc_add_column_if_missing(PDO $pdo, string $table, string $column, string $sql): void
{
    if (fc_column_exists($pdo, $table, $column)) {
        return;
    }

    try {
        $pdo->exec($sql);
    } catch (Throwable $e) {
        throw new RuntimeException(
            "Unable to add automatic-results column {$table}.{$column}: " . $e->getMessage(),
            0,
            $e
        );
    }

    if (!fc_column_exists($pdo, $table, $column)) {
        throw new RuntimeException("Automatic-results column {$table}.{$column} is still missing after migration.");
    }
}

function fc_ensure_automatic_results_schema(PDO $pdo): void
{
    // Result-type lookup table.
    $pdo->exec("CREATE TABLE IF NOT EXISTS result_types (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT,
        name VARCHAR(150) NOT NULL,
        code VARCHAR(80) NOT NULL,
        description VARCHAR(255) NULL,
        status VARCHAR(20) NOT NULL DEFAULT 'active',
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY uq_result_type_code (code),
        KEY idx_result_types_status (status)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $defaults = [
        ['BECE', 'bece', 'Basic Education Certificate Examination'],
        ['WASSCE School', 'wassce-school', 'West African Senior School Certificate Examination - School Candidates'],
        ['WASSCE Private', 'wassce-private', 'West African Senior School Certificate Examination - Private Candidates'],
    ];
    $insert = $pdo->prepare("INSERT INTO result_types (name, code, description, status) VALUES (?, ?, ?, 'active') ON DUPLICATE KEY UPDATE name=VALUES(name), description=VALUES(description), status='active'");
    foreach ($defaults as $row) {
        $insert->execute($row);
    }

    // Create the complete table when it does not exist.
    if (!fc_table_exists($pdo, 'result_requests')) {
        $pdo->exec("CREATE TABLE result_requests (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id INT UNSIGNED NULL,
            order_id BIGINT UNSIGNED NULL,
            result_type_id INT UNSIGNED NULL,
            result_type VARCHAR(80) NOT NULL,
            exam_year VARCHAR(10) NOT NULL,
            index_number VARCHAR(80) NOT NULL,
            date_of_birth DATE NULL,
            status VARCHAR(40) NOT NULL DEFAULT 'pending',
            provider VARCHAR(80) NULL,
            provider_reference VARCHAR(191) NULL,
            voucher_id BIGINT UNSIGNED NULL,
            error_message TEXT NULL,
            result_payload LONGTEXT NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            processed_at DATETIME NULL,
            PRIMARY KEY (id),
            KEY idx_result_requests_status (status),
            KEY idx_result_requests_type_year (result_type, exam_year),
            KEY idx_result_requests_index (index_number),
            KEY idx_result_requests_user (user_id),
            KEY idx_result_requests_order (order_id),
            KEY idx_result_requests_result_type_id (result_type_id),
            KEY idx_result_requests_voucher (voucher_id),
            CONSTRAINT fk_result_requests_type FOREIGN KEY (result_type_id) REFERENCES result_types(id) ON UPDATE CASCADE ON DELETE SET NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        return;
    }

    // Upgrade older tables in place. We deliberately use NULL/default-friendly
    // columns to avoid breaking existing rows.
    fc_add_column_if_missing($pdo, 'result_requests', 'user_id',
        "ALTER TABLE result_requests ADD COLUMN user_id INT UNSIGNED NULL AFTER id");
    fc_add_column_if_missing($pdo, 'result_requests', 'order_id',
        "ALTER TABLE result_requests ADD COLUMN order_id BIGINT UNSIGNED NULL AFTER user_id");
    fc_add_column_if_missing($pdo, 'result_requests', 'result_type_id',
        "ALTER TABLE result_requests ADD COLUMN result_type_id INT UNSIGNED NULL AFTER order_id");
    fc_add_column_if_missing($pdo, 'result_requests', 'result_type',
        "ALTER TABLE result_requests ADD COLUMN result_type VARCHAR(80) NULL AFTER result_type_id");
    fc_add_column_if_missing($pdo, 'result_requests', 'exam_year',
        "ALTER TABLE result_requests ADD COLUMN exam_year VARCHAR(10) NULL AFTER result_type");
    fc_add_column_if_missing($pdo, 'result_requests', 'index_number',
        "ALTER TABLE result_requests ADD COLUMN index_number VARCHAR(80) NULL AFTER exam_year");
    fc_add_column_if_missing($pdo, 'result_requests', 'date_of_birth',
        "ALTER TABLE result_requests ADD COLUMN date_of_birth DATE NULL AFTER index_number");
    fc_add_column_if_missing($pdo, 'result_requests', 'status',
        "ALTER TABLE result_requests ADD COLUMN status VARCHAR(40) NULL DEFAULT 'pending' AFTER date_of_birth");
    fc_add_column_if_missing($pdo, 'result_requests', 'provider',
        "ALTER TABLE result_requests ADD COLUMN provider VARCHAR(80) NULL AFTER status");
    fc_add_column_if_missing($pdo, 'result_requests', 'provider_reference',
        "ALTER TABLE result_requests ADD COLUMN provider_reference VARCHAR(191) NULL AFTER provider");
    fc_add_column_if_missing($pdo, 'result_requests', 'voucher_id',
        "ALTER TABLE result_requests ADD COLUMN voucher_id BIGINT UNSIGNED NULL AFTER provider_reference");
    fc_add_column_if_missing($pdo, 'result_requests', 'error_message',
        "ALTER TABLE result_requests ADD COLUMN error_message TEXT NULL AFTER voucher_id");
    fc_add_column_if_missing($pdo, 'result_requests', 'result_payload',
        "ALTER TABLE result_requests ADD COLUMN result_payload LONGTEXT NULL AFTER error_message");
    fc_add_column_if_missing($pdo, 'result_requests', 'created_at',
        "ALTER TABLE result_requests ADD COLUMN created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP AFTER result_payload");
    fc_add_column_if_missing($pdo, 'result_requests', 'updated_at',
        "ALTER TABLE result_requests ADD COLUMN updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP AFTER created_at");
    fc_add_column_if_missing($pdo, 'result_requests', 'processed_at',
        "ALTER TABLE result_requests ADD COLUMN processed_at DATETIME NULL AFTER updated_at");
    fc_add_column_if_missing($pdo, 'result_requests', 'result_access_token',
        "ALTER TABLE result_requests ADD COLUMN result_access_token CHAR(64) NULL AFTER processed_at");
    try {
        $pdo->exec("ALTER TABLE result_requests ADD UNIQUE KEY uq_result_access_token (result_access_token)");
    } catch (Throwable $e) {
        // Index may already exist.
    }

    // Ensure our required values can be written even if an older version used
    // a restrictive ENUM/type. Only normalize when possible; don't destroy data.
    try {
        $pdo->exec("ALTER TABLE result_requests MODIFY COLUMN status VARCHAR(40) NOT NULL DEFAULT 'pending'");
    } catch (Throwable $e) {
        error_log('FastCheckerGH automatic-results status migration warning: ' . $e->getMessage());
    }

    // Keep a legacy result_type_id foreign-key column synchronized with the
    // human-readable result_type code when older database versions use it.
    if (fc_column_exists($pdo, 'result_requests', 'result_type_id')) {
        try {
            $pdo->exec("UPDATE result_requests rr INNER JOIN result_types rt ON rt.code = rr.result_type SET rr.result_type_id = rt.id WHERE (rr.result_type_id IS NULL OR rr.result_type_id = 0) AND rr.result_type IS NOT NULL AND rr.result_type <> ''");
        } catch (Throwable $e) {
            error_log('FastCheckerGH result_type_id backfill warning: ' . $e->getMessage());
        }
    }

    // Add missing indexes where possible.
    try {
        $pdo->exec("ALTER TABLE result_requests ADD KEY idx_result_requests_order (order_id)");
    } catch (Throwable $e) {
        // Index may already exist; safe to ignore duplicate-index errors.
    }
    try {
        $pdo->exec("ALTER TABLE result_requests ADD KEY idx_result_requests_voucher (voucher_id)");
    } catch (Throwable $e) {
        // Index may already exist; safe to ignore duplicate-index errors.
    }
}

fc_ensure_automatic_results_schema($pdo);
