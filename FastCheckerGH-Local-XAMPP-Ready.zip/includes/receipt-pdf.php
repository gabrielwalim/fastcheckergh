<?php
/**
 * FastCheckerGH - lightweight, dependency-free PDF receipt generator.
 *
 * Uses the PDF standard 14 fonts (Helvetica) so no font files or Composer
 * packages are required on local XAMPP or shared hosting.
 */

final class FastCheckerGHPdfReceipt
{
    private array $objects = [];
    private string $stream = '';
    private float $pageWidth = 595.28;   // A4 points
    private float $pageHeight = 841.89;  // A4 points
    private float $margin = 44.0;
    private float $y = 797.0;
    private array $lines = [];

    public function __construct()
    {
        $this->stream = "q\n";
        $this->setFillColor(1, 1, 1);
        $this->rect(0, 0, $this->pageWidth, $this->pageHeight, true);
        $this->setFillColor(0.125, 0.137, 0.176);
    }

    private function esc(string $text): string
    {
        $text = str_replace(["\\", "(", ")"], ["\\\\", "\\(", "\\)"], $text);
        return preg_replace('/[^\x09\x0A\x0D\x20-\x7E]/', '', $text) ?? '';
    }

    private function setFillColor(float $r, float $g, float $b): void
    {
        $this->stream .= sprintf("%.4f %.4f %.4f rg\n", $r, $g, $b);
    }

    private function setStrokeColor(float $r, float $g, float $b): void
    {
        $this->stream .= sprintf("%.4f %.4f %.4f RG\n", $r, $g, $b);
    }

    private function setLineWidth(float $width): void
    {
        $this->stream .= sprintf("%.2f w\n", $width);
    }

    private function rect(float $x, float $y, float $w, float $h, bool $fill = false): void
    {
        $this->stream .= sprintf("%.2f %.2f %.2f %.2f re\n", $x, $y, $w, $h);
        $this->stream .= $fill ? "f\n" : "S\n";
    }

    private function line(float $x1, float $y1, float $x2, float $y2): void
    {
        $this->stream .= sprintf("%.2f %.2f m %.2f %.2f l S\n", $x1, $y1, $x2, $y2);
    }

    private function text(float $x, float $y, float $size, string $text, string $font = 'F1'): void
    {
        $this->stream .= sprintf(
            "BT /%s %.2f Tf %.2f %.2f Td (%s) Tj ET\n",
            $font,
            $size,
            $x,
            $y,
            $this->esc($text)
        );
    }

    private function textRight(float $rightX, float $y, float $size, string $text, string $font = 'F1'): void
    {
        $safe = $this->esc($text);
        $width = max(0, strlen($safe) * $size * 0.50);
        $this->text(max($this->margin, $rightX - $width), $y, $size, $text, $font);
    }

    private function wrap(string $text, int $maxChars): array
    {
        $text = trim(preg_replace('/\s+/', ' ', $text) ?? '');
        if ($text === '') {
            return [''];
        }
        return str_split_word($text, $maxChars);
    }

    private function sectionTitle(string $title): void
    {
        $this->y -= 20;
        $this->setFillColor(1, 0.396, 0);
        $this->text($this->margin, $this->y, 10, strtoupper($title), 'F2');
        $this->setStrokeColor(0.90, 0.90, 0.92);
        $this->setLineWidth(0.7);
        $this->line($this->margin, $this->y - 7, $this->pageWidth - $this->margin, $this->y - 7);
        $this->setFillColor(0.125, 0.137, 0.176);
        $this->y -= 24;
    }

    private function ensureSpace(float $needed): void
    {
        if ($this->y - $needed < 48) {
            // This receipt is intentionally kept to one A4 page. If more space
            // is needed, move down until the content fits rather than clipping.
            $this->y = max(48, $this->y - $needed);
        }
    }

    public function build(array $data): string
    {
        $this->setFillColor(0.125, 0.137, 0.176);
        $this->text($this->margin, $this->y, 24, 'FastChecker', 'F2');
        $this->setFillColor(1, 0.396, 0);
        $this->text($this->margin + 126, $this->y, 24, 'GH', 'F2');
        $this->setFillColor(0.40, 0.41, 0.45);
        $this->text($this->margin, $this->y - 20, 9, 'Secure online result checking in Ghana');

        $this->setFillColor(1, 0.396, 0);
        $this->rect($this->pageWidth - $this->margin - 118, $this->y - 30, 118, 38, true);
        $this->setFillColor(1, 1, 1);
        $this->text($this->pageWidth - $this->margin - 99, $this->y - 6, 11, 'PAYMENT RECEIPT', 'F2');

        $this->setFillColor(0.125, 0.137, 0.176);
        $this->y -= 58;
        $this->setStrokeColor(0.90, 0.90, 0.92);
        $this->setLineWidth(0.8);
        $this->line($this->margin, $this->y, $this->pageWidth - $this->margin, $this->y);

        $this->sectionTitle('Transaction details');
        $this->row('Reference', (string)($data['reference'] ?? ''));
        $this->row('Order ID', (string)($data['order_id'] ?? ''));
        $this->row('Date', (string)($data['purchase_date'] ?? ''));
        $this->row('Customer phone', (string)($data['customer_phone'] ?? ''));
        $this->row('Product', (string)($data['product_name'] ?? 'Result Checker'));
        $this->row('Quantity', (string)($data['quantity'] ?? count($data['vouchers'] ?? [])));
        if (!empty($data['amount'])) {
            $this->row('Amount paid', 'GHS ' . number_format((float)$data['amount'], 2));
        }
        $this->row('Payment status', 'Successful');

        $this->sectionTitle('Checker voucher');
        foreach (array_values($data['vouchers'] ?? []) as $index => $voucher) {
            $serial = (string)($voucher['serial_number'] ?? '');
            $pin = (string)($voucher['pin'] ?? '');
            $label = count($data['vouchers'] ?? []) > 1 ? 'Checker ' . ($index + 1) : 'Checker';
            $this->setFillColor(1, 0.973, 0.949);
            $this->rect($this->margin, $this->y - 68, $this->pageWidth - 2 * $this->margin, 58, true);
            $this->setStrokeColor(1, 0.84, 0.74);
            $this->setLineWidth(0.8);
            $this->rect($this->margin, $this->y - 68, $this->pageWidth - 2 * $this->margin, 58, false);
            $this->setFillColor(0.125, 0.137, 0.176);
            $this->text($this->margin + 14, $this->y - 20, 10, $label, 'F2');
            $this->text($this->margin + 14, $this->y - 42, 9, 'Serial: ' . $serial, 'F2');
            $this->text($this->margin + 250, $this->y - 42, 9, 'PIN: ' . $pin, 'F2');
            $this->y -= 78;
        }

        $this->sectionTitle('Official verification');
        $officialUrl = (string)($data['official_url'] ?? 'https://eresults.waecgh.org/');
        foreach ($this->wrap($officialUrl, 76) as $line) {
            $this->text($this->margin, $this->y, 9, $line);
            $this->y -= 13;
        }

        $this->y -= 18;
        $this->setFillColor(0.96, 0.96, 0.97);
        $this->rect($this->margin, $this->y - 58, $this->pageWidth - 2 * $this->margin, 50, true);
        $this->setFillColor(0.18, 0.19, 0.23);
        $this->text($this->margin + 14, $this->y - 21, 9, 'Thank you for using FastCheckerGH.', 'F2');
        $this->text($this->margin + 14, $this->y - 37, 8, 'Keep this receipt for your records. FastCheckerGH will never ask you to share your PIN publicly.');

        $this->setFillColor(0.55, 0.56, 0.60);
        $this->text($this->margin, 42, 8, 'FastCheckerGH - fastcheckergh.com');
        $this->textRight($this->pageWidth - $this->margin, 42, 8, 'Generated securely');

        $this->stream .= "Q\n";

        return $this->buildPdfDocument($this->stream);
    }

    private function row(string $label, string $value): void
    {
        $this->ensureSpace(22);
        $this->setFillColor(0.40, 0.41, 0.45);
        $this->text($this->margin, $this->y, 9, $label);
        $this->setFillColor(0.125, 0.137, 0.176);
        $this->textRight($this->pageWidth - $this->margin, $this->y, 9, $value, 'F2');
        $this->y -= 17;
    }

    private function buildPdfDocument(string $content): string
    {
        $objects = [];
        $objects[1] = '<< /Type /Catalog /Pages 2 0 R >>';
        $objects[2] = '<< /Type /Pages /Kids [3 0 R] /Count 1 >>';
        $objects[3] = '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595.28 841.89] /Resources << /Font << /F1 4 0 R /F2 5 0 R >> >> /Contents 6 0 R >>';
        $objects[4] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>';
        $objects[5] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>';
        $objects[6] = '<< /Length ' . strlen($content) . " >>\nstream\n" . $content . "endstream";

        $pdf = "%PDF-1.4\n%\xE2\xE3\xCF\xD3\n";
        $offsets = [0];
        foreach ($objects as $number => $object) {
            $offsets[$number] = strlen($pdf);
            $pdf .= $number . " 0 obj\n" . $object . "\nendobj\n";
        }
        $xref = strlen($pdf);
        $pdf .= "xref\n0 " . (count($objects) + 1) . "\n";
        $pdf .= "0000000000 65535 f \n";
        for ($i = 1; $i <= count($objects); $i++) {
            $pdf .= sprintf("%010d 00000 n \n", $offsets[$i]);
        }
        $pdf .= "trailer\n<< /Size " . (count($objects) + 1) . " /Root 1 0 R >>\n";
        $pdf .= "startxref\n" . $xref . "\n%%EOF";
        return $pdf;
    }
}

/** Word wrap helper kept outside the class to keep the PDF class self-contained. */
function str_split_word(string $text, int $width): array
{
    $words = preg_split('/\s+/', trim($text)) ?: [''];
    $lines = [];
    $current = '';
    foreach ($words as $word) {
        $candidate = $current === '' ? $word : $current . ' ' . $word;
        if (strlen($candidate) <= $width) {
            $current = $candidate;
        } else {
            if ($current !== '') {
                $lines[] = $current;
            }
            $current = $word;
        }
    }
    if ($current !== '') {
        $lines[] = $current;
    }
    return $lines ?: [''];
}
