<?php
/**
 * Update selected keys in FastCheckerGH .env without destroying unrelated settings.
 */
function fc_update_env_keys(string $file, array $updates): bool
{
    $existing = is_file($file) && is_readable($file) ? file($file, FILE_IGNORE_NEW_LINES) : [];
    if ($existing === false) {
        $existing = [];
    }

    $normalized = [];
    foreach ($updates as $key => $value) {
        $normalized[(string)$key] = (string)$value;
    }

    $seen = [];
    $output = [];
    foreach ($existing as $line) {
        $trim = trim($line);
        if ($trim === '' || $trim[0] === '#') {
            $output[] = $line;
            continue;
        }
        $pos = strpos($line, '=');
        if ($pos === false) {
            $output[] = $line;
            continue;
        }
        $key = trim(substr($line, 0, $pos));
        if (array_key_exists($key, $normalized)) {
            $output[] = $key . '=' . $normalized[$key];
            $seen[$key] = true;
        } else {
            $output[] = $line;
        }
    }

    foreach ($normalized as $key => $value) {
        if (!isset($seen[$key])) {
            $output[] = $key . '=' . $value;
        }
    }

    return @file_put_contents($file, implode(PHP_EOL, $output) . PHP_EOL, LOCK_EX) !== false;
}
