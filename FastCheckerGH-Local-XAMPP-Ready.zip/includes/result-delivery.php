<?php
require_once __DIR__ . '/env.php';

/**
 * Ensure the notification log table exists for older FastCheckerGH databases.
 */
function fc_ensure_notification_logs_table(PDO $pdo): void
{
    static $ready = false;
    if ($ready) {
        return;
    }

    $pdo->exec("CREATE TABLE IF NOT EXISTS notification_logs (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        channel ENUM('sms','whatsapp','email') NOT NULL,
        recipient VARCHAR(255) NOT NULL,
        status ENUM('pending','sent','failed') NOT NULL DEFAULT 'pending',
        message TEXT NULL,
        provider_reference VARCHAR(191) NULL,
        error_message TEXT NULL,
        order_id INT UNSIGNED NULL,
        user_id INT UNSIGNED NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        sent_at DATETIME NULL,
        PRIMARY KEY (id),
        KEY idx_notification_channel_status (channel,status),
        KEY idx_notification_order (order_id),
        KEY idx_notification_user (user_id),
        KEY idx_notification_created (created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $ready = true;
}

function fc_delivery_log(
    PDO $pdo,
    string $channel,
    string $recipient,
    string $status,
    string $message,
    ?string $reference = null,
    ?string $error = null,
    ?int $orderId = null,
    ?int $userId = null
): void {
    try {
        fc_ensure_notification_logs_table($pdo);
        $st = $pdo->prepare("INSERT INTO notification_logs
            (channel, recipient, status, message, provider_reference, error_message, order_id, user_id, sent_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $st->execute([
            $channel,
            $recipient,
            $status,
            $message,
            $reference,
            $error,
            $orderId,
            $userId,
            $status === 'sent' ? date('Y-m-d H:i:s') : null,
        ]);
    } catch (Throwable $e) {
        error_log('FastCheckerGH notification log failed: ' . $e->getMessage());
    }
}

function fc_delivery_was_sent(PDO $pdo, string $channel, ?int $orderId): bool
{
    if (!$orderId) {
        return false;
    }

    try {
        fc_ensure_notification_logs_table($pdo);
        $st = $pdo->prepare("SELECT id FROM notification_logs
            WHERE channel = ? AND order_id = ? AND status = 'sent'
            ORDER BY id DESC LIMIT 1");
        $st->execute([$channel, $orderId]);
        return (bool)$st->fetchColumn();
    } catch (Throwable $e) {
        error_log('FastCheckerGH notification deduplication check failed: ' . $e->getMessage());
        return false;
    }
}

function fc_brevo_request(string $endpoint, array $payload, array $extraHeaders = []): array
{
    $apiKey = trim((string)getenv('BREVO_API_KEY'));
    if ($apiKey === '') {
        return ['success' => false, 'message' => 'BREVO_API_KEY is not configured.'];
    }
    if (!function_exists('curl_init')) {
        return ['success' => false, 'message' => 'PHP cURL is not enabled.'];
    }

    $headers = array_merge([
        'accept: application/json',
        'api-key: ' . $apiKey,
        'content-type: application/json',
    ], $extraHeaders);

    $ch = curl_init('https://api.brevo.com' . $endpoint);
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
        CURLOPT_HTTPHEADER => $headers,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_CONNECTTIMEOUT => 10,
    ]);

    $body = curl_exec($ch);
    $err = curl_error($ch);
    $http = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($body === false) {
        return ['success' => false, 'message' => $err ?: 'Brevo connection failed.'];
    }

    $data = json_decode((string)$body, true);
    if ($http < 200 || $http >= 300 || !is_array($data)) {
        return [
            'success' => false,
            'message' => is_array($data)
                ? (string)($data['message'] ?? 'Brevo request failed.')
                : 'Brevo returned an invalid response.',
            'http_code' => $http,
            'raw' => $body,
        ];
    }

    return ['success' => true, 'data' => $data, 'http_code' => $http];
}

function fc_normalize_recipient_phone(string $phone): string
{
    $phone = trim($phone);
    $digits = preg_replace('/\D+/', '', $phone);

    if ($digits === '') {
        return '';
    }

    if (strpos($digits, '00') === 0) {
        $digits = substr($digits, 2);
    }

    // Ghana local numbers: 0XXXXXXXXX -> 233XXXXXXXXX
    if (strlen($digits) === 10 && $digits[0] === '0') {
        $digits = '233' . substr($digits, 1);
    }

    return $digits;
}

function fc_send_brevo_email(
    PDO $pdo,
    string $to,
    string $subject,
    string $html,
    ?int $orderId = null,
    ?int $userId = null,
    bool $sandbox = false
): array {
    $to = trim($to);
    if (!filter_var($to, FILTER_VALIDATE_EMAIL)) {
        return ['success' => false, 'message' => 'No valid recipient email address.'];
    }

    $sender = trim((string)getenv('BREVO_EMAIL_SENDER'));
    $senderName = trim((string)(getenv('BREVO_EMAIL_SENDER_NAME') ?: 'FastCheckerGH'));
    $replyTo = trim((string)getenv('BREVO_EMAIL_REPLY_TO'));
    if ($sender === '' || !filter_var($sender, FILTER_VALIDATE_EMAIL)) {
        return ['success' => false, 'message' => 'BREVO_EMAIL_SENDER is not configured with a valid email address.'];
    }

    $payload = [
        'sender' => ['name' => $senderName, 'email' => $sender],
        'to' => [['email' => $to]],
        'subject' => $subject,
        'htmlContent' => $html,
    ];
    if ($replyTo !== '' && filter_var($replyTo, FILTER_VALIDATE_EMAIL)) {
        $payload['replyTo'] = ['email' => $replyTo];
    }

    $extraHeaders = $sandbox ? ['X-Sib-Sandbox: drop'] : [];
    $res = fc_brevo_request('/v3/smtp/email', $payload, $extraHeaders);

    fc_delivery_log(
        $pdo,
        'email',
        $to,
        $res['success'] ? 'sent' : 'failed',
        $subject,
        $res['success'] ? (string)($res['data']['messageId'] ?? '') : null,
        $res['success'] ? null : (string)$res['message'],
        $orderId,
        $userId
    );

    return $res;
}

function fc_send_brevo_sms(
    PDO $pdo,
    string $phone,
    string $message,
    ?int $orderId = null,
    ?int $userId = null
): array {
    $to = fc_normalize_recipient_phone($phone);
    if ($to === '') {
        return ['success' => false, 'message' => 'No valid recipient phone number.'];
    }

    $sender = trim((string)(getenv('BREVO_SMS_SENDER') ?: 'FastCheckerGH'));
    if ($sender === '') {
        return ['success' => false, 'message' => 'BREVO_SMS_SENDER is not configured.'];
    }

    $payload = [
        'sender' => $sender,
        'recipient' => $to,
        'content' => $message,
        'type' => 'transactional',
    ];

    $res = fc_brevo_request('/v3/transactionalSMS/send', $payload);
    fc_delivery_log(
        $pdo,
        'sms',
        $to,
        $res['success'] ? 'sent' : 'failed',
        $message,
        $res['success'] ? (string)($res['data']['messageId'] ?? '') : null,
        $res['success'] ? null : (string)$res['message'],
        $orderId,
        $userId
    );

    return $res;
}

function fc_send_brevo_whatsapp(
    PDO $pdo,
    string $phone,
    string $message,
    array $templateParams = [],
    ?int $orderId = null,
    ?int $userId = null
): array {
    $to = fc_normalize_recipient_phone($phone);
    if ($to === '') {
        return ['success' => false, 'message' => 'No valid WhatsApp recipient number.'];
    }

    $sender = fc_normalize_recipient_phone((string)getenv('BREVO_WHATSAPP_SENDER'));
    if ($sender === '') {
        return ['success' => false, 'message' => 'BREVO_WHATSAPP_SENDER is not configured.'];
    }

    $templateId = trim((string)getenv('BREVO_WHATSAPP_TEMPLATE_ID'));
    $allowText = filter_var((string)(getenv('BREVO_WHATSAPP_ALLOW_TEXT') ?: '0'), FILTER_VALIDATE_BOOLEAN);

    $payload = [
        'senderNumber' => $sender,
        'contactNumbers' => [$to],
    ];

    if ($templateId !== '') {
        if (!ctype_digit($templateId)) {
            return ['success' => false, 'message' => 'BREVO_WHATSAPP_TEMPLATE_ID must be numeric.'];
        }
        $payload['templateId'] = (int)$templateId;
        if ($templateParams) {
            // Brevo supports template parameters for transactional WhatsApp messages.
            $payload['params'] = $templateParams;
        }
    } elseif ($allowText) {
        $payload['text'] = $message;
    } else {
        return [
            'success' => false,
            'message' => 'WhatsApp is not ready: configure an approved BREVO_WHATSAPP_TEMPLATE_ID or explicitly enable BREVO_WHATSAPP_ALLOW_TEXT=1.',
        ];
    }

    $res = fc_brevo_request('/v3/whatsapp/sendMessage', $payload);
    fc_delivery_log(
        $pdo,
        'whatsapp',
        $to,
        $res['success'] ? 'sent' : 'failed',
        $message,
        $res['success'] ? (string)($res['data']['messageId'] ?? '') : null,
        $res['success'] ? null : (string)$res['message'],
        $orderId,
        $userId
    );

    return $res;
}

function fc_send_result_email(PDO $pdo, array $request, array $result, string $viewUrl): array
{
    $to = trim((string)($request['email'] ?? ''));
    if (!filter_var($to, FILTER_VALIDATE_EMAIL)) {
        return ['success' => false, 'message' => 'No valid recipient email address.'];
    }
    if (fc_delivery_was_sent($pdo, 'email', isset($request['order_id']) ? (int)$request['order_id'] : null)) {
        return ['success' => true, 'message' => 'Result email was already delivered for this order.', 'skipped' => true];
    }

    $candidate = htmlspecialchars((string)($result['candidate_name'] ?? ''), ENT_QUOTES, 'UTF-8');
    $exam = htmlspecialchars((string)($result['exam'] ?? $request['result_type'] ?? ''), ENT_QUOTES, 'UTF-8');
    $year = htmlspecialchars((string)($result['year'] ?? $request['exam_year'] ?? ''), ENT_QUOTES, 'UTF-8');
    $index = htmlspecialchars((string)($result['index_number'] ?? $request['index_number'] ?? ''), ENT_QUOTES, 'UTF-8');
    $rows = '';
    foreach (($result['subjects'] ?? []) as $row) {
        $rows .= '<tr>'
            . '<td style="padding:8px;border-bottom:1px solid #eee">' . htmlspecialchars((string)($row['subject'] ?? ''), ENT_QUOTES, 'UTF-8') . '</td>'
            . '<td style="padding:8px;border-bottom:1px solid #eee">' . htmlspecialchars((string)($row['score'] ?? ''), ENT_QUOTES, 'UTF-8') . '</td>'
            . '<td style="padding:8px;border-bottom:1px solid #eee">' . htmlspecialchars((string)($row['grade'] ?? ''), ENT_QUOTES, 'UTF-8') . '</td>'
            . '<td style="padding:8px;border-bottom:1px solid #eee">' . htmlspecialchars((string)($row['remark'] ?? ''), ENT_QUOTES, 'UTF-8') . '</td>'
            . '</tr>';
    }

    $safeUrl = htmlspecialchars($viewUrl, ENT_QUOTES, 'UTF-8');
    $html = '<div style="font-family:Arial,sans-serif;color:#20232d;max-width:720px;margin:auto">'
        . '<h2 style="margin-bottom:8px">FastChecker<span style="color:#ff6500">GH</span> Result</h2>'
        . '<p>Your result is now available.</p>'
        . '<p><strong>Candidate:</strong> ' . $candidate . '</p>'
        . '<p><strong>Examination:</strong> ' . $exam . ' &nbsp; <strong>Year:</strong> ' . $year . ' &nbsp; <strong>Index:</strong> ' . $index . '</p>'
        . '<table cellpadding="0" cellspacing="0" width="100%" style="border-collapse:collapse">'
        . '<thead><tr><th align="left" style="padding:8px;border-bottom:2px solid #ff6500">Subject</th><th align="left" style="padding:8px;border-bottom:2px solid #ff6500">Score</th><th align="left" style="padding:8px;border-bottom:2px solid #ff6500">Grade</th><th align="left" style="padding:8px;border-bottom:2px solid #ff6500">Remark</th></tr></thead>'
        . '<tbody>' . $rows . '</tbody></table>'
        . '<p style="margin-top:20px"><a href="' . $safeUrl . '" style="background:#ff6500;color:#fff;padding:12px 18px;text-decoration:none;border-radius:5px">View Result Securely</a></p>'
        . '<p style="color:#666;font-size:12px">For official verification, use the WAEC Ghana verification service.</p>'
        . '</div>';

    $sandbox = filter_var((string)(getenv('BREVO_EMAIL_SANDBOX') ?: '0'), FILTER_VALIDATE_BOOLEAN);
    return fc_send_brevo_email(
        $pdo,
        $to,
        'Your ' . strip_tags($exam) . ' ' . strip_tags($year) . ' Result - FastCheckerGH',
        $html,
        isset($request['order_id']) ? (int)$request['order_id'] : null,
        isset($request['user_id']) ? (int)$request['user_id'] : null,
        $sandbox
    );
}

function fc_send_result_sms(PDO $pdo, array $request, array $result, string $viewUrl): array
{
    $phone = trim((string)($request['phone'] ?? ''));
    if ($phone === '') {
        return ['success' => false, 'message' => 'No recipient phone number.'];
    }
    if (fc_delivery_was_sent($pdo, 'sms', isset($request['order_id']) ? (int)$request['order_id'] : null)) {
        return ['success' => true, 'message' => 'Result SMS was already delivered for this order.', 'skipped' => true];
    }

    $exam = (string)($result['exam'] ?? $request['result_type'] ?? '');
    $year = (string)($result['year'] ?? $request['exam_year'] ?? '');
    $message = 'FastCheckerGH: Your ' . $exam . ' ' . $year . ' result is ready. View: ' . $viewUrl;

    return fc_send_brevo_sms(
        $pdo,
        $phone,
        $message,
        isset($request['order_id']) ? (int)$request['order_id'] : null,
        isset($request['user_id']) ? (int)$request['user_id'] : null
    );
}

function fc_send_result_whatsapp(PDO $pdo, array $request, array $result, string $viewUrl): array
{
    $phone = trim((string)($request['phone'] ?? ''));
    if ($phone === '') {
        return ['success' => false, 'message' => 'No WhatsApp recipient number.'];
    }
    if (fc_delivery_was_sent($pdo, 'whatsapp', isset($request['order_id']) ? (int)$request['order_id'] : null)) {
        return ['success' => true, 'message' => 'Result WhatsApp message was already delivered for this order.', 'skipped' => true];
    }

    $exam = (string)($result['exam'] ?? $request['result_type'] ?? '');
    $year = (string)($result['year'] ?? $request['exam_year'] ?? '');
    $candidate = (string)($result['candidate_name'] ?? 'Candidate');
    $message = 'FastCheckerGH: ' . $candidate . '\'s ' . $exam . ' ' . $year . ' result is ready. View securely: ' . $viewUrl;

    // Template parameter order is configured as: candidate, exam, year, result_url.
    $templateParams = [$candidate, $exam, $year, $viewUrl];

    return fc_send_brevo_whatsapp(
        $pdo,
        $phone,
        $message,
        $templateParams,
        isset($request['order_id']) ? (int)$request['order_id'] : null,
        isset($request['user_id']) ? (int)$request['user_id'] : null
    );
}

function fc_deliver_result(PDO $pdo, array $request, array $result, string $viewUrl): array
{
    return [
        'email' => fc_send_result_email($pdo, $request, $result, $viewUrl),
        'sms' => fc_send_result_sms($pdo, $request, $result, $viewUrl),
        'whatsapp' => fc_send_result_whatsapp($pdo, $request, $result, $viewUrl),
    ];
}
