<?php
require_once __DIR__ . '/env.php';

function fc_result_provider_mode(): string
{
    $mode = strtolower(trim((string)(getenv('RESULT_PROVIDER') ?: 'official_portal')));
    return in_array($mode, ['official_portal', 'waec_api'], true) ? $mode : 'official_portal';
}

function fc_official_results_url(): string
{
    return 'https://eresults.waecgh.org/';
}

function fc_result_provider_configured(): bool
{
    return trim((string)getenv('WAEC_API_URL')) !== '' &&
        trim((string)getenv('WAEC_API_TOKEN')) !== '' &&
        preg_match('#^https://#i', trim((string)getenv('WAEC_API_URL'))) === 1;
}

/**
 * FastCheckerGH normalized result contract.
 * The upstream endpoint must be an authorized WAEC API/RVS endpoint.
 * We do not scrape the public eResults page and we do not invent an endpoint.
 *
 * Expected normalized response from the configured endpoint:
 * {
 *   "success": true,
 *   "reference": "...",
 *   "data": {
 *      "candidate_name": "...",
 *      "index_number": "...",
 *      "exam": "BECE",
 *      "year": "2025",
 *      "subjects": [
 *         {"subject":"English Language","grade":"A1","score":80}
 *      ],
 *      "overall": {"remark":"..."}
 *   }
 * }
 *
 * A provider can also return data/result/results; the normalizer below handles
 * common response envelopes without claiming knowledge of a private schema.
 */
function fc_normalize_provider_result(array $response, array $request): array
{
    $data = $response['data'] ?? $response['result'] ?? $response['results'] ?? $response;
    if (isset($data['data']) && is_array($data['data'])) {
        $data = $data['data'];
    }
    if (!is_array($data)) {
        return ['success'=>false,'status'=>'invalid_response','message'=>'The result provider returned an invalid data structure.'];
    }

    $subjects = [];
    foreach (['subjects','subject_results','grades','results'] as $key) {
        if (isset($data[$key]) && is_array($data[$key])) {
            $candidateSubjects = $data[$key];
            foreach ($candidateSubjects as $row) {
                if (!is_array($row)) continue;
                $subjects[] = [
                    'subject' => (string)($row['subject'] ?? $row['name'] ?? $row['subject_name'] ?? ''),
                    'score' => $row['score'] ?? $row['mark'] ?? $row['percentage'] ?? null,
                    'grade' => (string)($row['grade'] ?? $row['result'] ?? $row['symbol'] ?? ''),
                    'remark' => (string)($row['remark'] ?? $row['remarks'] ?? ''),
                ];
            }
            if ($subjects) break;
        }
    }

    $normalized = [
        'candidate_name' => (string)($data['candidate_name'] ?? $data['candidateName'] ?? $data['name'] ?? ''),
        'index_number' => (string)($data['index_number'] ?? $data['indexNumber'] ?? $request['index_number']),
        'exam' => (string)($data['exam'] ?? $data['exam_type'] ?? $request['result_type']),
        'year' => (string)($data['year'] ?? $data['exam_year'] ?? $request['exam_year']),
        'subjects' => $subjects,
        'overall' => is_array($data['overall'] ?? null) ? $data['overall'] : [
            'remark' => (string)($data['overall_remark'] ?? $data['remark'] ?? ''),
            'aggregate' => $data['aggregate'] ?? null,
        ],
        'raw' => $data,
    ];

    if ($normalized['candidate_name'] === '' && !$normalized['subjects'] && empty($normalized['raw'])) {
        return ['success'=>false,'status'=>'empty_result','message'=>'The provider returned no candidate result data.'];
    }

    return [
        'success' => true,
        'status' => 'completed',
        'reference' => (string)($response['reference'] ?? $response['verification_reference'] ?? $response['id'] ?? ''),
        'data' => $normalized,
        'raw_response' => $response,
    ];
}

function fc_submit_to_waec_api(array $payload): array
{
    $baseUrl = trim((string)(getenv('WAEC_API_URL') ?: ''));
    $token = trim((string)(getenv('WAEC_API_TOKEN') ?: ''));
    if ($baseUrl === '' || $token === '') {
        return [
            'success' => false,
            'status' => 'provider_unavailable',
            'message' => 'Authorized WAEC API credentials are not configured.'
        ];
    }
    if (stripos($baseUrl, 'https://') !== 0) {
        return ['success'=>false,'status'=>'configuration_error','message'=>'WAEC API URL must use HTTPS.'];
    }
    if (!function_exists('curl_init')) {
        return ['success'=>false,'status'=>'server_configuration_error','message'=>'PHP cURL is not enabled on this server.'];
    }

    $headerName = trim((string)(getenv('WAEC_API_AUTH_HEADER') ?: 'Authorization'));
    $scheme = trim((string)(getenv('WAEC_API_AUTH_SCHEME') ?: 'Bearer'));
    $authValue = $scheme !== '' ? $scheme . ' ' . $token : $token;
    $timeout = max(5, min(120, (int)(getenv('WAEC_API_TIMEOUT') ?: 30)));
    $verifySsl = ((string)(getenv('WAEC_API_VERIFY_SSL') ?: '1') !== '0');

    $headers = [
        'Accept: application/json',
        'Content-Type: application/json',
        $headerName . ': ' . $authValue,
    ];

    $ch = curl_init($baseUrl);
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
        CURLOPT_HTTPHEADER => $headers,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_TIMEOUT => $timeout,
        CURLOPT_SSL_VERIFYPEER => $verifySsl,
        CURLOPT_SSL_VERIFYHOST => $verifySsl ? 2 : 0,
    ]);
    $body = curl_exec($ch);
    $curlError = curl_error($ch);
    $http = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($body === false) {
        return ['success'=>false,'status'=>'network_error','message'=>'Unable to reach the authorized WAEC result provider: ' . $curlError];
    }
    $decoded = json_decode((string)$body, true);
    if (!is_array($decoded)) {
        return ['success'=>false,'status'=>'invalid_response','message'=>'The WAEC result provider returned a non-JSON response.','http_code'=>$http];
    }
    if ($http < 200 || $http >= 300) {
        $message = (string)($decoded['message'] ?? $decoded['error'] ?? 'The WAEC result provider rejected the request.');
        return ['success'=>false,'status'=>'provider_error','message'=>$message,'http_code'=>$http,'raw_response'=>$decoded];
    }
    if (isset($decoded['success']) && !$decoded['success']) {
        return ['success'=>false,'status'=>'provider_error','message'=>(string)($decoded['message'] ?? 'The WAEC result provider did not return a result.'),'http_code'=>$http,'raw_response'=>$decoded];
    }

    return fc_normalize_provider_result($decoded, $payload);
}
