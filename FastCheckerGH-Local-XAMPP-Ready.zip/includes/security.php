<?php
/**
 * FastCheckerGH security helpers.
 */

function fc_is_https(): bool
{
    return !empty($_SERVER['HTTPS']) && strtolower((string)$_SERVER['HTTPS']) !== 'off';
}

function fc_client_ip(): string
{
    // Do not trust forwarded headers unless your reverse proxy is explicitly configured.
    return (string)($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0');
}

function fc_security_headers(): void
{
    if (headers_sent()) {
        return;
    }

    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: SAMEORIGIN');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('Permissions-Policy: geolocation=(), microphone=(), camera=()');

    if (fc_is_https()) {
        header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
    }
}

function fc_start_secure_session(string $name = 'FASTCHECKERGH_SESSION'): void
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        return;
    }

    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    ini_set('session.cookie_httponly', '1');
    ini_set('session.cookie_samesite', 'Lax');

    session_name($name);
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'secure' => fc_is_https(),
        'httponly' => true,
        'samesite' => 'Lax',
    ]);

    session_start();
}

function fc_debug_enabled(): bool
{
    $env = strtolower(trim((string)(getenv('APP_ENV') ?: 'local')));
    return $env !== 'production' && filter_var(getenv('APP_DEBUG') !== false ? getenv('APP_DEBUG') : '1', FILTER_VALIDATE_BOOLEAN);
}

function fc_configure_error_reporting(): void
{
    if (!fc_debug_enabled()) {
        ini_set('display_errors', '0');
        ini_set('display_startup_errors', '0');
        error_reporting(E_ALL);
    }
}

function fc_csrf_token(string $sessionKey = 'fc_csrf'): string
{
    if (empty($_SESSION[$sessionKey])) {
        $_SESSION[$sessionKey] = bin2hex(random_bytes(32));
    }
    return (string)$_SESSION[$sessionKey];
}

function fc_verify_csrf(?string $token, string $sessionKey = 'fc_csrf'): bool
{
    return is_string($token) && isset($_SESSION[$sessionKey]) && hash_equals((string)$_SESSION[$sessionKey], $token);
}
