<?php
/**
 * FastCheckerGH phone-number helpers.
 * Canonical storage format for Ghana numbers: +233XXXXXXXXX.
 */

function fc_clean_phone(string $phone): string
{
    $phone = trim($phone);
    return preg_replace('/[^0-9+]/', '', $phone) ?? '';
}

function fc_phone_variants(string $phone): array
{
    $clean = fc_clean_phone($phone);
    if ($clean === '') {
        return [];
    }

    $digits = ltrim($clean, '+');
    $variants = [$clean];

    // Ghana local mobile format: 0XXXXXXXXX (10 digits).
    if (preg_match('/^0\d{9}$/', $digits)) {
        $international = '+233' . substr($digits, 1);
        $variants[] = $international;
        $variants[] = '233' . substr($digits, 1);
    }

    // Ghana international format without plus: 233XXXXXXXXX (12 digits).
    if (preg_match('/^233\d{9}$/', $digits)) {
        $variants[] = '+' . $digits;
        $variants[] = '0' . substr($digits, 3);
    }

    // Normalize +233XXXXXXXXX.
    if (preg_match('/^\+233\d{9}$/', $clean)) {
        $variants[] = ltrim($clean, '+');
        $variants[] = '0' . substr($clean, 4);
    }

    $variants = array_values(array_unique(array_filter($variants)));
    return $variants;
}

function fc_canonical_phone(string $phone): string
{
    $variants = fc_phone_variants($phone);
    if (!$variants) {
        return '';
    }

    foreach ($variants as $variant) {
        $digits = ltrim($variant, '+');
        if (preg_match('/^233\d{9}$/', $digits)) {
            return '+' . $digits;
        }
    }

    return $variants[0];
}

function fc_phone_international_digits(string $phone): string
{
    $canonical = fc_canonical_phone($phone);
    return ltrim($canonical, '+');
}
