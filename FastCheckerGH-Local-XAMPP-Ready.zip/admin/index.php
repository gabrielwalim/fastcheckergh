<?php
require_once __DIR__ . '/auth.php';
admin_require_login();

function admin_scalar(PDO $pdo, string $sql, array $params = [], $fallback = 0) {
    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $value = $stmt->fetchColumn();
        return $value === false || $value === null ? $fallback : $value;
    } catch (Throwable $e) {
        error_log('FastCheckerGH admin query: ' . $e->getMessage());
        return $fallback;
    }
}

$stats = [
    'customers' => (int)admin_scalar($pdo, 'SELECT COUNT(*) FROM users'),
    'orders' => (int)admin_scalar($pdo, 'SELECT COUNT(*) FROM orders'),
    'paid_orders' => (int)admin_scalar($pdo, "SELECT COUNT(*) FROM orders WHERE status IN ('paid','completed')"),
    'revenue' => (float)admin_scalar($pdo, "SELECT COALESCE(SUM(total_amount),0) FROM orders WHERE status IN ('paid','completed')"),
    'available_vouchers' => (int)admin_scalar($pdo, "SELECT COUNT(*) FROM vouchers WHERE status = 'available' AND order_id IS NULL"),
    'assigned_vouchers' => (int)admin_scalar($pdo, "SELECT COUNT(*) FROM vouchers WHERE status = 'assigned'"),
    'pending_results' => (int)admin_scalar($pdo, "SELECT COUNT(*) FROM result_requests WHERE status = 'pending'"),
    'failed_payments' => (int)admin_scalar($pdo, "SELECT COUNT(*) FROM payments WHERE status IN ('failed','abandoned')"),
];

$recentOrders = [];
try {
    $stmt = $pdo->query("SELECT o.id, o.total_amount, o.status, o.created_at, u.phone, u.email, p.name AS product_name, oi.quantity FROM orders o JOIN users u ON u.id=o.user_id LEFT JOIN order_items oi ON oi.order_id=o.id LEFT JOIN products p ON p.id=oi.product_id ORDER BY o.id DESC LIMIT 12");
    $recentOrders = $stmt->fetchAll();
} catch (Throwable $e) { error_log('FastCheckerGH admin orders: '.$e->getMessage()); }

$recentResults = [];
try {
    $stmt = $pdo->query("SELECT id, result_type, exam_year, index_number, date_of_birth, status, created_at FROM result_requests ORDER BY id DESC LIMIT 8");
    $recentResults = $stmt->fetchAll();
} catch (Throwable $e) { error_log('FastCheckerGH admin results: '.$e->getMessage()); }

$lowStock = [];
try {
    $stmt = $pdo->query("SELECT p.id, p.name, COUNT(v.id) AS available FROM products p LEFT JOIN vouchers v ON v.product_id=p.id AND v.status='available' AND v.order_id IS NULL GROUP BY p.id,p.name ORDER BY available ASC, p.id ASC LIMIT 8");
    $lowStock = $stmt->fetchAll();
} catch (Throwable $e) { error_log('FastCheckerGH admin stock: '.$e->getMessage()); }

$notifications = [];
try {
    $stmt = $pdo->query("SELECT channel, recipient, status, message, created_at FROM notification_logs ORDER BY id DESC LIMIT 8");
    $notifications = $stmt->fetchAll();
} catch (Throwable $e) { /* Phase 4 table may not exist yet. */ }
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Admin Dashboard - FastCheckerGH</title>
<link rel="stylesheet" href="admin.css">
</head>
<body class="admin-body">
<header class="admin-topbar">
    <a class="admin-brand" href="index.php"><span>FastChecker</span><b>GH</b></a>
    <div class="admin-user"><span><?php echo admin_e($_SESSION['admin_name'] ?? 'Administrator'); ?></span><a href="logout.php">Logout</a></div>
</header>
<div class="admin-shell">
    <aside class="admin-sidebar">
        <a class="active" href="index.php">Dashboard</a>
        <a href="orders.php">Orders & Payments</a>
        <a href="vouchers.php">Voucher Inventory</a>
        <a href="users.php">Customers</a>
        <a href="results.php">Result Requests</a>
        <a href="notifications.php">Notifications</a><a href="delivery-test.php">Delivery Test</a>
        <a href="paystack-settings.php">Paystack Settings</a>
        <a href="paystack-test.php">Paystack Connection</a>
        <a href="export-orders.php">Export Orders</a>
        <a href="../index.php">View Website</a>
    </aside>
    <main class="admin-main">
        <div class="page-title"><div><p class="eyebrow">FASTCHECKERGH</p><h1>Dashboard</h1><p class="muted">Overview of your checker sales and operations.</p></div></div>

        <section class="stat-grid">
            <div class="stat-card"><span>Customers</span><strong><?php echo number_format($stats['customers']); ?></strong></div>
            <div class="stat-card"><span>Total orders</span><strong><?php echo number_format($stats['orders']); ?></strong></div>
            <div class="stat-card"><span>Paid / completed</span><strong><?php echo number_format($stats['paid_orders']); ?></strong></div>
            <div class="stat-card"><span>Revenue</span><strong>GH₵ <?php echo number_format($stats['revenue'], 2); ?></strong></div>
            <div class="stat-card"><span>Available vouchers</span><strong><?php echo number_format($stats['available_vouchers']); ?></strong></div>
            <div class="stat-card"><span>Assigned vouchers</span><strong><?php echo number_format($stats['assigned_vouchers']); ?></strong></div>
            <div class="stat-card"><span>Pending results</span><strong><?php echo number_format($stats['pending_results']); ?></strong></div>
            <div class="stat-card"><span>Failed payments</span><strong><?php echo number_format($stats['failed_payments']); ?></strong></div>
        </section>

        <div class="two-col">
            <section class="panel">
                <div class="panel-head"><h2>Recent orders</h2><a href="orders.php">View all</a></div>
                <div class="table-wrap"><table><thead><tr><th>Order</th><th>Customer</th><th>Product</th><th>Total</th><th>Status</th></tr></thead><tbody>
                <?php foreach ($recentOrders as $row): ?>
                    <tr><td>#<?php echo (int)$row['id']; ?></td><td><?php echo admin_e($row['phone']); ?><small><?php echo admin_e($row['email']); ?></small></td><td><?php echo admin_e($row['product_name'] ?? '—'); ?> × <?php echo (int)($row['quantity'] ?? 0); ?></td><td>GH₵ <?php echo number_format((float)$row['total_amount'],2); ?></td><td><span class="badge <?php echo admin_e($row['status']); ?>"><?php echo admin_e($row['status']); ?></span></td></tr>
                <?php endforeach; ?>
                <?php if (!$recentOrders): ?><tr><td colspan="5" class="empty">No orders found.</td></tr><?php endif; ?>
                </tbody></table></div>
            </section>
            <section class="panel">
                <div class="panel-head"><h2>Voucher stock</h2><a href="vouchers.php">Inventory</a></div>
                <div class="stock-list">
                <?php foreach ($lowStock as $row): ?><div class="stock-row"><span><?php echo admin_e($row['name']); ?></span><strong><?php echo number_format((int)$row['available']); ?></strong></div><?php endforeach; ?>
                <?php if (!$lowStock): ?><p class="empty">No product stock data found.</p><?php endif; ?>
                </div>
            </section>
        </div>

        <div class="two-col">
            <section class="panel">
                <div class="panel-head"><h2>Result requests</h2><a href="results.php">View all</a></div>
                <div class="table-wrap"><table><thead><tr><th>ID</th><th>Type</th><th>Year</th><th>Index</th><th>Status</th></tr></thead><tbody>
                <?php foreach ($recentResults as $row): ?><tr><td>#<?php echo (int)$row['id']; ?></td><td><?php echo admin_e($row['result_type']); ?></td><td><?php echo admin_e($row['exam_year']); ?></td><td><?php echo admin_e($row['index_number']); ?></td><td><span class="badge <?php echo admin_e($row['status']); ?>"><?php echo admin_e($row['status']); ?></span></td></tr><?php endforeach; ?>
                <?php if (!$recentResults): ?><tr><td colspan="5" class="empty">No result requests found.</td></tr><?php endif; ?>
                </tbody></table></div>
            </section>
            <section class="panel">
                <div class="panel-head"><h2>Latest notifications</h2><a href="notifications.php">View all</a></div>
                <div class="stock-list">
                <?php foreach ($notifications as $row): ?><div class="notification-row"><div><strong><?php echo admin_e(strtoupper($row['channel'])); ?></strong> · <?php echo admin_e($row['recipient']); ?><small><?php echo admin_e($row['message']); ?></small></div><span class="badge <?php echo admin_e($row['status']); ?>"><?php echo admin_e($row['status']); ?></span></div><?php endforeach; ?>
                <?php if (!$notifications): ?><p class="empty">No notification log records found.</p><?php endif; ?>
                </div>
            </section>
        </div>
    </main>
</div>
</body>
</html>
