<?php
require_once __DIR__ . '/auth.php';
admin_require_login();
require_once __DIR__ . '/../includes/automatic-results-schema.php';

$q = trim((string)($_GET['q'] ?? ''));
$params = [];
$where = '';
if ($q !== '') {
    $like = '%' . $q . '%';
    $where = 'WHERE rr.result_type LIKE ? OR rr.exam_year LIKE ? OR rr.index_number LIKE ? OR rr.status LIKE ? OR rr.provider LIKE ?';
    $params = [$like,$like,$like,$like,$like];
}
$st = $pdo->prepare("SELECT rr.id, rr.result_type, rr.exam_year, rr.index_number, rr.date_of_birth, rr.status, rr.provider, rr.voucher_id, rr.error_message, rr.created_at, rr.processed_at FROM result_requests rr $where ORDER BY rr.id DESC LIMIT 250");
$st->execute($params);
$rows = $st->fetchAll();
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Result Requests - FastCheckerGH</title><link rel="stylesheet" href="admin.css"></head><body class="admin-body"><header class="admin-topbar"><a class="admin-brand" href="index.php"><span>FastChecker</span><b>GH</b></a><div class="admin-user"><span><?php echo admin_e($_SESSION['admin_name']??'Administrator'); ?></span><a href="logout.php">Logout</a></div></header><div class="admin-shell"><aside class="admin-sidebar"><a href="index.php">Dashboard</a><a href="orders.php">Orders & Payments</a><a href="vouchers.php">Voucher Inventory</a><a href="upload-vouchers.php">Upload Checkers</a><a href="users.php">Customers</a><a class="active" href="results.php">Result Requests</a><a href="result-provider.php">Result Provider</a><a href="notifications.php">Notifications</a><a href="delivery-test.php">Delivery Test</a><a href="paystack-test.php">Paystack Connection</a><a href="export-orders.php">Export Orders</a><a href="../index.php">View Website</a></aside><main class="admin-main"><div class="page-title"><div><p class="eyebrow">AUTOMATIC CHECKER</p><h1>Result Requests</h1><p class="muted">Monitor candidate requests and provider status.</p></div></div><form class="toolbar" method="get"><input name="q" value="<?php echo admin_e($q); ?>" placeholder="Search type, year, index, status or provider"><button class="btn primary">Search</button></form><section class="panel"><div class="table-wrap"><table><thead><tr><th>ID</th><th>Type</th><th>Year</th><th>Index</th><th>Voucher</th><th>Provider</th><th>Status</th><th>Created</th><th>Processed</th></tr></thead><tbody><?php foreach($rows as $r): ?><tr><td>#<?php echo (int)$r['id']; ?></td><td><?php echo admin_e($r['result_type']); ?></td><td><?php echo admin_e($r['exam_year']); ?></td><td><?php echo admin_e($r['index_number']); ?></td><td><?php echo $r['voucher_id'] ? '#'.(int)$r['voucher_id'] : '—'; ?></td><td><?php echo admin_e($r['provider'] ?: '—'); ?></td><td><span class="badge <?php echo admin_e($r['status']); ?>"><?php echo admin_e($r['status']); ?></span><?php if (!empty($r['error_message'])): ?><br><small class="muted"><?php echo admin_e($r['error_message']); ?></small><?php endif; ?></td><td><?php echo admin_e($r['created_at']); ?></td><td><?php echo admin_e($r['processed_at'] ?: '—'); ?></td></tr><?php endforeach; ?><?php if(!$rows): ?><tr><td colspan="9" class="empty">No result requests found.</td></tr><?php endif; ?></tbody></table></div></section></main></div></body></html>
