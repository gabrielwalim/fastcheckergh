<?php
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/../includes/env.php';
require_once __DIR__ . '/../includes/env-writer.php';

admin_require_login();

$message = null;
$messageType = 'success';

function fc_normalize_secret(string $secret): string
{
    $secret = trim($secret);
    $secret = preg_replace('/^\s*Authorization\s*:\s*/i', '', $secret);
    $secret = preg_replace('/^\s*Bearer\s+/i', '', $secret);
    return trim((string)$secret);
}

function fc_valid_secret(string $secret): bool
{
    return (bool)preg_match('/^sk_(test|live)_[A-Za-z0-9]+$/', $secret);
}

$envFile = dirname(__DIR__) . DIRECTORY_SEPARATOR . '.env';
$currentSecret = trim((string)(getenv('PAYSTACK_SECRET_KEY') ?: ''));
$currentSiteUrl = rtrim(trim((string)(getenv('FASTCHECKERGH_SITE_URL') ?: 'http://localhost/fastcheckergh')), '/');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!admin_verify_csrf($_POST['csrf_token'] ?? null)) {
        $messageType = 'error';
        $message = 'Security check failed. Refresh the page and try again.';
    } else {
        $submittedSecret = fc_normalize_secret((string)($_POST['paystack_secret_key'] ?? ''));
        $siteUrl = rtrim(trim((string)($_POST['site_url'] ?? 'http://localhost/fastcheckergh')), '/');

        if ($submittedSecret === '') {
            $submittedSecret = $currentSecret;
        }

        if (!fc_valid_secret($submittedSecret)) {
            $messageType = 'error';
            $message = 'Enter a valid Paystack Secret Key beginning with sk_test_ or sk_live_. Do not enter "Bearer" or "Authorization:".';
        } elseif ($siteUrl === '' || !filter_var($siteUrl, FILTER_VALIDATE_URL)) {
            $messageType = 'error';
            $message = 'Enter a valid website URL, for example http://localhost/fastcheckergh.';
        } else {
            $saved = fc_update_env_keys($envFile, [
                'PAYSTACK_SECRET_KEY' => $submittedSecret,
                'PAYSTACK_API_URL' => 'https://api.paystack.co',
                'FASTCHECKERGH_SITE_URL' => $siteUrl,
            ]);
            if (!$saved) {
                $messageType = 'error';
                $message = 'FastCheckerGH could not write the .env file. Check that the project folder is writable by Apache/PHP.';
            } else {
                // Refresh this request immediately without requiring a restart.
                putenv('PAYSTACK_SECRET_KEY=' . $submittedSecret);
                putenv('PAYSTACK_API_URL=https://api.paystack.co');
                putenv('FASTCHECKERGH_SITE_URL=' . $siteUrl);
                $_ENV['PAYSTACK_SECRET_KEY'] = $submittedSecret;
                $_ENV['PAYSTACK_API_URL'] = 'https://api.paystack.co';
                $_ENV['FASTCHECKERGH_SITE_URL'] = $siteUrl;

                $currentSecret = $submittedSecret;
                $currentSiteUrl = $siteUrl;
                $message = 'Paystack settings saved successfully. You can now run the connection test.';
            }
        }
    }
}

$maskedKey = $currentSecret === ''
    ? 'Not configured'
    : substr($currentSecret, 0, 8) . '••••••••' . substr($currentSecret, -4);

$mode = (substr($currentSecret, 0, 8) === 'sk_live_') ? 'LIVE' : ((substr($currentSecret, 0, 8) === 'sk_test_') ? 'TEST' : 'NOT CONFIGURED');
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Paystack Settings - FastCheckerGH</title>
<link rel="stylesheet" href="admin.css">
</head>
<body class="admin-body">
<header class="admin-topbar">
    <a class="admin-brand" href="index.php"><span>FastChecker</span><b>GH</b></a>
    <div class="admin-user"><span><?php echo admin_e($_SESSION['admin_name'] ?? 'Administrator'); ?></span><a href="logout.php">Logout</a></div>
</header>
<div class="admin-shell">
    <aside class="admin-sidebar">
        <a href="index.php">Dashboard</a>
        <a href="orders.php">Orders & Payments</a>
        <a href="vouchers.php">Voucher Inventory</a>
        <a href="users.php">Customers</a>
        <a href="results.php">Result Requests</a>
        <a href="notifications.php">Notifications</a>
        <a class="active" href="paystack-settings.php">Paystack Settings</a>
        <a href="paystack-test.php">Paystack Connection</a>
        <a href="export-orders.php">Export Orders</a>
        <a href="../index.php">View Website</a>
    </aside>
    <main class="admin-main">
        <div class="page-title">
            <div>
                <p class="eyebrow">PAYMENTS</p>
                <h1>Paystack Settings</h1>
                <p class="muted">Configure the Paystack secret key without editing PHP files.</p>
            </div>
        </div>

        <?php if ($message): ?>
            <div class="alert <?php echo $messageType === 'success' ? 'success' : 'error'; ?>">
                <?php echo admin_e($message); ?>
            </div>
        <?php endif; ?>

        <section class="panel">
            <div class="panel-head"><h2>Current configuration</h2></div>
            <div style="padding:22px">
                <div class="table-wrap">
                    <table>
                        <tbody>
                            <tr><th>Paystack API</th><td>https://api.paystack.co</td></tr>
                            <tr><th>Key</th><td><?php echo admin_e($maskedKey); ?></td></tr>
                            <tr><th>Mode</th><td><strong><?php echo admin_e($mode); ?></strong></td></tr>
                            <tr><th>Site URL</th><td><?php echo admin_e($currentSiteUrl); ?></td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </section>

        <section class="panel" style="margin-top:18px">
            <div class="panel-head"><h2>Configure Paystack</h2></div>
            <div style="padding:22px">
                <form method="post">
                    <input type="hidden" name="csrf_token" value="<?php echo admin_e(admin_csrf_token()); ?>">
                    <div class="form-group">
                        <label for="paystack_secret_key">Paystack Secret Key</label>
                        <input id="paystack_secret_key" name="paystack_secret_key" type="password" autocomplete="off" placeholder="sk_test_... or sk_live_...">
                        <p class="muted" style="margin-top:7px;font-size:13px">Paste only the key itself. Do not include <code>Bearer</code> or <code>Authorization:</code>.</p>
                    </div>
                    <div class="form-group">
                        <label for="site_url">FastCheckerGH Site URL</label>
                        <input id="site_url" name="site_url" type="url" value="<?php echo admin_e($currentSiteUrl); ?>" required>
                    </div>
                    <button class="btn primary" type="submit">Save Paystack Settings</button>
                </form>
            </div>
        </section>

        <section class="panel" style="margin-top:18px">
            <div class="panel-head"><h2>Recommended workflow</h2></div>
            <div style="padding:22px;color:var(--muted);line-height:1.7">
                <p style="margin:0 0 8px">1. Start with your <strong>sk_test_...</strong> key.</p>
                <p style="margin:0 0 8px">2. Save the settings.</p>
                <p style="margin:0 0 8px">3. Open <strong>Paystack Connection</strong> and run the test.</p>
                <p style="margin:0">4. Only switch to a live key after the complete payment and voucher flow has been tested.</p>
            </div>
        </section>
    </main>
</div>
</body>
</html>
