<?php
// FastCheckerGH admin bootstrap installer.
// Use once on a local/development environment to create the admin tables and first administrator.
require_once __DIR__ . '/../includes/security.php';
fc_start_secure_session('FASTCHECKERGH_ADMIN_SETUP');

$fc_setup_env = strtolower(trim((string)(getenv('APP_ENV') ?: 'local')));
$fc_allow_setup = filter_var((string)(getenv('FCGH_ALLOW_SETUP') ?: '1'), FILTER_VALIDATE_BOOLEAN);
if ($fc_setup_env === 'production' && !$fc_allow_setup) {
    http_response_code(404);
    exit('Not found');
}
require_once __DIR__ . '/../includes/db.php';

$error = '';
$success = '';

function setup_e($value): string {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function admin_tables_ready(PDO $pdo): bool {
    try {
        $stmt = $pdo->query("SHOW TABLES LIKE 'admin_users'");
        return (bool)$stmt->fetchColumn();
    } catch (Throwable $e) {
        return false;
    }
}

function create_admin_tables(PDO $pdo): void {
    $pdo->exec("CREATE TABLE IF NOT EXISTS admin_users (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT,
        username VARCHAR(80) NOT NULL,
        password_hash VARCHAR(255) NOT NULL,
        full_name VARCHAR(150) NOT NULL DEFAULT 'Administrator',
        status ENUM('active','disabled') NOT NULL DEFAULT 'active',
        last_login_at DATETIME NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY uq_admin_username (username)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");


    $pdo->exec("CREATE TABLE IF NOT EXISTS checker_otps (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id INT UNSIGNED NULL,
        phone VARCHAR(32) NOT NULL,
        otp_hash VARCHAR(255) NOT NULL,
        expires_at DATETIME NOT NULL,
        attempts TINYINT UNSIGNED NOT NULL DEFAULT 0,
        verified TINYINT(1) NOT NULL DEFAULT 0,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY idx_checker_otps_phone_verified (phone, verified, id),
        KEY idx_checker_otps_expires (expires_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $pdo->exec("CREATE TABLE IF NOT EXISTS admin_login_attempts (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        username VARCHAR(80) NOT NULL,
        ip_hash CHAR(64) NOT NULL,
        attempts INT UNSIGNED NOT NULL DEFAULT 0,
        window_started_at DATETIME NOT NULL,
        locked_until DATETIME NULL,
        PRIMARY KEY (id),
        UNIQUE KEY uq_admin_login_attempt (username, ip_hash),
        KEY idx_admin_login_locked (locked_until)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $pdo->exec("CREATE TABLE IF NOT EXISTS notification_logs (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        channel ENUM('sms','whatsapp','email') NOT NULL,
        recipient VARCHAR(255) NOT NULL,
        status ENUM('pending','sent','failed') NOT NULL DEFAULT 'pending',
        message TEXT NULL,
        provider_reference VARCHAR(191) NULL,
        error_message TEXT NULL,
        order_id INT UNSIGNED NULL,
        user_id INT UNSIGNED NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        sent_at DATETIME NULL,
        PRIMARY KEY (id),
        KEY idx_notification_channel_status (channel,status),
        KEY idx_notification_order (order_id),
        KEY idx_notification_user (user_id),
        KEY idx_notification_created (created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}

try {
    if (!admin_tables_ready($pdo)) {
        create_admin_tables($pdo);
    } else {
        // Ensure the Phase 4 log table also exists when the admin table was created manually.
        create_admin_tables($pdo);
    }

    $countStmt = $pdo->query('SELECT COUNT(*) FROM admin_users');
    $adminCount = (int)$countStmt->fetchColumn();

    if ($adminCount > 0) {
        header('Location: login.php');
        exit;
    } elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (!fc_verify_csrf($_POST['csrf_token'] ?? null, 'admin_setup_csrf')) {
            throw new RuntimeException('Security check failed. Refresh the page and try again.');
        }
        $username = trim((string)($_POST['username'] ?? ''));
        $fullName = trim((string)($_POST['full_name'] ?? ''));
        $password = (string)($_POST['password'] ?? '');
        $confirm = (string)($_POST['confirm_password'] ?? '');

        if ($username === '' || !preg_match('/^[A-Za-z0-9._-]{3,80}$/', $username)) {
            $error = 'Use a valid username with 3–80 letters, numbers, dots, underscores or hyphens.';
        } elseif ($fullName === '') {
            $error = 'Enter the administrator name.';
        } elseif (strlen($password) < 10) {
            $error = 'Use a password of at least 10 characters.';
        } elseif ($password !== $confirm) {
            $error = 'The passwords do not match.';
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare('INSERT INTO admin_users (username, password_hash, full_name) VALUES (?, ?, ?)');
            $stmt->execute([$username, $hash, $fullName]);
            $success = 'Administrator created successfully. Sign in to continue.';
            $adminCount = 1;
        }
    }
} catch (Throwable $e) {
    error_log('FastCheckerGH admin setup: ' . $e->getMessage());
    $error = 'Setup could not complete. Check that MySQL is running and the fastcheckergh database exists.';
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Admin Setup - FastCheckerGH</title>
<link rel="stylesheet" href="admin.css">
</head>
<body class="admin-login-page">
<div class="login-card">
    <div class="admin-brand"><span>FastChecker</span><b>GH</b></div>
    <p class="eyebrow">FIRST-TIME SETUP</p>
    <h1>Admin setup</h1>
    <p class="muted">Create the admin, messaging and retrieval database tables and your first administrator account.</p>
    <?php if ($error): ?><div class="alert error"><?php echo setup_e($error); ?></div><?php endif; ?>
    <?php if ($success): ?><div class="alert success"><?php echo setup_e($success); ?></div><?php endif; ?>

    <?php if ($adminCount === 0): ?>
    <form method="post" autocomplete="off">
        <input type="hidden" name="csrf_token" value="<?php echo setup_e(fc_csrf_token('admin_setup_csrf')); ?>">
        <label>Username<input name="username" required autocomplete="username" minlength="3" maxlength="80"></label>
        <label>Full name<input name="full_name" required maxlength="150"></label>
        <label>Password<input type="password" name="password" required minlength="10" autocomplete="new-password"></label>
        <label>Confirm password<input type="password" name="confirm_password" required minlength="10" autocomplete="new-password"></label>
        <button class="btn primary" type="submit">Create Administrator</button>
    </form>
    <?php endif; ?>

    <a class="back-link" href="login.php">← Admin login</a>
</div>
</body>
</html>
