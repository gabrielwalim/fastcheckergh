<?php
require_once __DIR__ . '/auth.php'; admin_require_login();
header('Content-Type: text/csv; charset=UTF-8');
header('Content-Disposition: attachment; filename="fastcheckergh-orders-' . date('Y-m-d') . '.csv"');
$out=fopen('php://output','w'); fputcsv($out,['Order ID','Phone','Email','Product','Quantity','Total GHS','Order Status','Payment Reference','Payment Status','Created At']);
$st=$pdo->query("SELECT o.id,u.phone,u.email,p.name,oi.quantity,o.total_amount,o.status,pay.payment_reference,pay.status AS payment_status,o.created_at FROM orders o JOIN users u ON u.id=o.user_id LEFT JOIN order_items oi ON oi.order_id=o.id LEFT JOIN products p ON p.id=oi.product_id LEFT JOIN payments pay ON pay.order_id=o.id ORDER BY o.id DESC");
while($r=$st->fetch()) fputcsv($out,[$r['id'],$r['phone'],$r['email'],$r['name'],$r['quantity'],$r['total_amount'],$r['status'],$r['payment_reference'],$r['payment_status'],$r['created_at']]); fclose($out); exit;
