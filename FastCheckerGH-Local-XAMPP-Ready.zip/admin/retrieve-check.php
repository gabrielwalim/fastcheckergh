<?php
require_once __DIR__ . '/../includes/env.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/phone.php';

header('Content-Type: text/html; charset=UTF-8');
$checks = [];
function checkItem(&$checks, $name, $ok, $detail='') { $checks[] = [$name, (bool)$ok, $detail]; }
try {
    checkItem($checks, 'PHP version', version_compare(PHP_VERSION, '7.4.0', '>='), PHP_VERSION);
    checkItem($checks, 'PDO MySQL', extension_loaded('pdo_mysql'), extension_loaded('pdo_mysql') ? 'Loaded' : 'Missing');
    checkItem($checks, 'Database connection', true, 'Connected to ' . (getenv('DB_NAME') ?: 'fastcheckergh'));
    $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
    foreach (['users','orders','vouchers','products'] as $t) checkItem($checks, 'Table: '.$t, in_array($t, $tables, true), in_array($t, $tables, true) ? 'Found' : 'Missing');
    $pdo->exec("CREATE TABLE IF NOT EXISTS checker_otps (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id INT UNSIGNED NULL,
        phone VARCHAR(32) NOT NULL,
        otp_hash VARCHAR(255) NOT NULL,
        expires_at DATETIME NOT NULL,
        attempts TINYINT UNSIGNED NOT NULL DEFAULT 0,
        verified TINYINT(1) NOT NULL DEFAULT 0,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id), KEY idx_checker_otps_phone_verified (phone, verified, id), KEY idx_checker_otps_expires (expires_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    checkItem($checks, 'Table: checker_otps', true, 'Ready');
    $cols = $pdo->query("SHOW COLUMNS FROM users")->fetchAll(PDO::FETCH_COLUMN);
    foreach (['id','phone','email'] as $c) checkItem($checks, 'users.'.$c, in_array($c, $cols, true), in_array($c, $cols, true) ? 'Found' : 'Missing');
    $input = $_GET['phone'] ?? '';
    if ($input !== '') {
        $canonical = fc_canonical_phone($input);
        $variants = fc_phone_variants($canonical);
        checkItem($checks, 'Phone normalization', $canonical !== '', $canonical ?: 'Invalid');
        if ($canonical !== '') {
            $ph = implode(',', array_fill(0,count($variants),'?'));
            $st=$pdo->prepare("SELECT id,phone,email FROM users WHERE phone IN ($ph) ORDER BY id DESC LIMIT 1");
            $st->execute($variants); $u=$st->fetch();
            checkItem($checks, 'Customer lookup', (bool)$u, $u ? ('User #'.$u['id'].' / '.$u['phone']) : 'No matching purchase account');
        }
    }
} catch (Throwable $e) {
    checkItem($checks, 'Runtime exception', false, $e->getMessage());
}
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Retrieve Diagnostics - FastCheckerGH</title><link rel="stylesheet" href="admin.css"></head><body class="admin-body"><div class="admin-main" style="max-width:900px;margin:auto"><h1>Retrieve Old Checkers Diagnostics</h1><p>This local diagnostic helps identify the exact database/PHP issue. Remove or disable this page before production.</p><table class="data-table"><thead><tr><th>Check</th><th>Status</th><th>Details</th></tr></thead><tbody><?php foreach($checks as $c): ?><tr><td><?php echo htmlspecialchars($c[0], ENT_QUOTES, 'UTF-8'); ?></td><td><?php echo $c[1] ? 'OK' : 'FAIL'; ?></td><td><?php echo htmlspecialchars($c[2], ENT_QUOTES, 'UTF-8'); ?></td></tr><?php endforeach; ?></tbody></table><p style="margin-top:20px"><form method="get"><input name="phone" placeholder="0550358919 or +233550358919" value="<?php echo htmlspecialchars($_GET['phone'] ?? '', ENT_QUOTES, 'UTF-8'); ?>"><button class="btn primary" type="submit">Test customer lookup</button></form></p></div></body></html>
