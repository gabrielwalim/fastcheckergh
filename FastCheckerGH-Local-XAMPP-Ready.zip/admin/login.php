<?php
require_once __DIR__ . '/auth.php';

if (admin_is_logged_in()) {
    header('Location: index.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!admin_verify_csrf($_POST['csrf'] ?? null)) {
        $error = 'Your session expired. Please try again.';
    } else {
        $username = trim((string)($_POST['username'] ?? ''));
        $password = (string)($_POST['password'] ?? '');

        if ($username === '' || $password === '') {
            $error = 'Enter your username and password.';
        } elseif (admin_login_is_limited($username)) {
            $error = 'Too many failed login attempts. Please wait 15 minutes and try again.';
        } else {
            try {
                $stmt = $pdo->prepare('SELECT id, username, password_hash, full_name, status FROM admin_users WHERE username = ? LIMIT 1');
                $stmt->execute([$username]);
                $admin = $stmt->fetch();
            } catch (PDOException $e) {
                if ((int)$e->getCode() === 0 || strpos($e->getMessage(), 'Base table or view not found') !== false) {
                    header('Location: setup.php');
                    exit;
                }
                throw $e;
            }

            if ($admin && $admin['status'] === 'active' && password_verify($password, $admin['password_hash'])) {
                session_regenerate_id(true);
                $_SESSION['admin_user_id'] = (int)$admin['id'];
                $_SESSION['admin_username'] = $admin['username'];
                $_SESSION['admin_name'] = $admin['full_name'] ?: $admin['username'];
                $_SESSION['admin_csrf'] = bin2hex(random_bytes(32));
                admin_clear_login_failures($username);

                $pdo->prepare('UPDATE admin_users SET last_login_at = NOW() WHERE id = ?')->execute([(int)$admin['id']]);
                header('Location: index.php');
                exit;
            }

            admin_record_login_failure($username);
            $error = 'Invalid admin credentials.';
        }
    }
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Admin Login - FastCheckerGH</title>
<link rel="stylesheet" href="admin.css">
</head>
<body class="admin-login-page">
<div class="login-card">
    <div class="admin-brand"><span>FastChecker</span><b>GH</b></div>
    <p class="eyebrow">ADMINISTRATOR</p>
    <h1>Sign in</h1>
    <p class="muted">Manage orders, payments, vouchers and result requests.</p>
    <?php if ($error): ?><div class="alert error"><?php echo admin_e($error); ?></div><?php endif; ?>
    <form method="post" autocomplete="off">
        <input type="hidden" name="csrf" value="<?php echo admin_e(admin_csrf_token()); ?>">
        <label>Username<input name="username" required autocomplete="username"></label>
        <label>Password<input type="password" name="password" required autocomplete="current-password"></label>
        <button class="btn primary" type="submit">Sign in</button>
    </form>
    <a class="back-link" href="setup.php">First-time admin setup</a><a class="back-link" href="../index.php">← Back to FastCheckerGH</a>
</div>
</body>
</html>
