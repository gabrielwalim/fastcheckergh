# FastCheckerGH Phase 5 — Admin Dashboard

## Install
1. Make sure MySQL is running and the existing `fastcheckergh` database is available.
2. Open `/admin/setup.php` in your local XAMPP site. It creates `admin_users` and `notification_logs` and lets you create the first administrator securely.
3. After setup, open `/admin/login.php`.
4. For manual installation, you can still import `admin/schema.sql` and insert an admin using a PHP-generated password hash.
5. After installation, keep database credentials and application secrets outside the public web root where possible.

## Included
- Dashboard statistics
- Orders and Paystack payment view
- Voucher inventory view (PINs masked)
- Customer list
- Automatic result request list
- SMS/WhatsApp/email notification log view
- CSV order export
- Session-based admin authentication and CSRF token for login

This phase is intentionally read-only for business records. Voucher deletion, price changes, user deletion and other destructive operations should be added only after the Phase 6 authorization/audit controls are completed.

## Troubleshooting
If `/admin/login.php` reports `Table 'fastcheckergh.admin_users' doesn't exist`, open `/admin/setup.php` once. The login page also redirects there automatically when the admin table is missing. After creating the first administrator, setup is complete.

### Upload checker cards
Use `upload-vouchers.php` after logging in as an administrator. Select `BECE Checker` or `WASSCE Checker`, then upload a CSV with two columns: `serial_number,pin`. You can also paste rows directly. New cards are stored as `available` and are eligible for automatic assignment after successful Paystack payment. Duplicate serial numbers/PINs are skipped.

## Production webhook

Set the Paystack webhook URL to `https://YOUR-DOMAIN/api/paystack-webhook.php`. The endpoint validates Paystack's `x-paystack-signature` header before synchronizing payment state.
