<?php
require_once __DIR__ . '/auth.php';
admin_require_login();

$errors = [];
$success = '';
$imported = 0;
$skipped = [];
$maxRows = 5000;

try {
    $productStmt = $pdo->query("SELECT id, name FROM products WHERE status = 'active' ORDER BY name ASC");
    $products = $productStmt->fetchAll();
} catch (Throwable $e) {
    $products = [];
    $errors[] = 'Unable to load products from the database.';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!admin_verify_csrf($_POST['csrf'] ?? null)) {
        $errors[] = 'Invalid security token. Please refresh the page and try again.';
    }

    $productId = (int)($_POST['product_id'] ?? 0);
    $rows = [];

    if (!$errors) {
        $productCheck = $pdo->prepare("SELECT id, name FROM products WHERE id = ? AND status = 'active' LIMIT 1");
        $productCheck->execute([$productId]);
        $selectedProduct = $productCheck->fetch();
        if (!$selectedProduct) {
            $errors[] = 'Please select a valid active checker product.';
        }
    }

    if (!$errors && isset($_FILES['checker_csv']) && $_FILES['checker_csv']['error'] !== UPLOAD_ERR_NO_FILE) {
        if ($_FILES['checker_csv']['error'] !== UPLOAD_ERR_OK) {
            $errors[] = 'The CSV upload failed. Please try again.';
        } elseif ($_FILES['checker_csv']['size'] > 2 * 1024 * 1024) {
            $errors[] = 'The CSV file is too large. Maximum size is 2 MB.';
        } else {
            $tmp = $_FILES['checker_csv']['tmp_name'];
            $fh = fopen($tmp, 'rb');
            if ($fh === false) {
                $errors[] = 'Unable to read the uploaded CSV file.';
            } else {
                $line = 0;
                while (($data = fgetcsv($fh)) !== false) {
                    $line++;
                    if ($line === 1) {
                        $first = isset($data[0]) ? preg_replace('/^\xEF\xBB\xBF/', '', trim((string)$data[0])) : '';
                        $second = isset($data[1]) ? trim((string)$data[1]) : '';
                        if (in_array(strtolower($first), ['serial_number','serial','serial number'], true) && in_array(strtolower($second), ['pin','pin_number','pin number'], true)) {
                            continue;
                        }
                    }
                    $serial = trim((string)($data[0] ?? ''));
                    $pin = trim((string)($data[1] ?? ''));
                    if ($serial === '' && $pin === '') {
                        continue;
                    }
                    $rows[] = ['serial_number' => $serial, 'pin' => $pin, 'line' => $line];
                    if (count($rows) >= $maxRows) {
                        break;
                    }
                }
                fclose($fh);
            }
        }
    }

    $paste = trim((string)($_POST['checker_list'] ?? ''));
    if (!$errors && $paste !== '') {
        foreach (preg_split('/\r\n|\r|\n/', $paste) as $offset => $lineText) {
            $lineText = trim($lineText);
            if ($lineText === '') {
                continue;
            }
            $parts = str_getcsv($lineText);
            $serial = trim((string)($parts[0] ?? ''));
            $pin = trim((string)($parts[1] ?? ''));
            if (strcasecmp($serial, 'serial_number') === 0 && strcasecmp($pin, 'pin') === 0) {
                continue;
            }
            $rows[] = ['serial_number' => $serial, 'pin' => $pin, 'line' => 'paste:' . ($offset + 1)];
            if (count($rows) >= $maxRows) {
                break;
            }
        }
    }

    if (!$errors && !$rows) {
        $errors[] = 'Provide a CSV file or paste at least one checker row.';
    }

    if (!$errors && count($rows) > $maxRows) {
        $errors[] = 'You can import a maximum of ' . number_format($maxRows) . ' checker cards at once.';
    }

    if (!$errors) {
        $seenSerials = [];
        $seenPins = [];
        $checkStmt = $pdo->prepare("SELECT id, serial_number, pin FROM vouchers WHERE serial_number = ? OR pin = ? LIMIT 1");
        $insertStmt = $pdo->prepare("INSERT INTO vouchers (product_id, serial_number, pin, status, order_id) VALUES (?, ?, ?, 'available', NULL)");

        try {
            $pdo->beginTransaction();

            foreach ($rows as $row) {
                $serial = $row['serial_number'];
                $pin = $row['pin'];

                if ($serial === '' || $pin === '') {
                    $skipped[] = $row['line'] . ' — serial number and PIN are both required.';
                    continue;
                }

                if (mb_strlen($serial) > 191 || mb_strlen($pin) > 191) {
                    $skipped[] = $row['line'] . ' — serial number or PIN is too long.';
                    continue;
                }

                $serialKey = mb_strtolower($serial);
                $pinKey = mb_strtolower($pin);
                if (isset($seenSerials[$serialKey])) {
                    $skipped[] = $row['line'] . ' — duplicate serial number in this upload.';
                    continue;
                }
                if (isset($seenPins[$pinKey])) {
                    $skipped[] = $row['line'] . ' — duplicate PIN in this upload.';
                    continue;
                }
                $seenSerials[$serialKey] = true;
                $seenPins[$pinKey] = true;

                $checkStmt->execute([$serial, $pin]);
                if ($checkStmt->fetch()) {
                    $skipped[] = $row['line'] . ' — serial number or PIN already exists.';
                    continue;
                }

                $insertStmt->execute([$productId, $serial, $pin]);
                $imported++;
            }

            $pdo->commit();
            $success = $imported . ' checker card(s) imported successfully for ' . $selectedProduct['name'] . '.';
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $imported = 0;
            $errors[] = 'The import could not be completed. No new checker cards were saved.';
        }
    }
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Upload Checker Cards - FastCheckerGH</title>
<link rel="stylesheet" href="admin.css">
</head>
<body class="admin-body">
<header class="admin-topbar">
    <a class="admin-brand" href="index.php"><span>FastChecker</span><b>GH</b></a>
    <div class="admin-user"><span><?php echo admin_e($_SESSION['admin_name'] ?? 'Administrator'); ?></span><a href="logout.php">Logout</a></div>
</header>
<div class="admin-shell">
<aside class="admin-sidebar">
    <a href="index.php">Dashboard</a>
    <a href="orders.php">Orders & Payments</a>
    <a class="active" href="vouchers.php">Voucher Inventory</a>
    <a href="upload-vouchers.php">Upload Checkers</a>
    <a href="users.php">Customers</a>
    <a href="results.php">Result Requests</a>
    <a href="notifications.php">Notifications</a><a href="delivery-test.php">Delivery Test</a>
        <a href="paystack-test.php">Paystack Connection</a>
    <a href="export-orders.php">Export Orders</a>
    <a href="../index.php">View Website</a>
</aside>
<main class="admin-main">
    <div class="page-title">
        <div>
            <p class="eyebrow">INVENTORY</p>
            <h1>Upload Checker Cards</h1>
            <p class="muted">Import serial numbers and PINs into the selected checker product.</p>
        </div>
        <a class="btn" href="vouchers.php">Back to inventory</a>
    </div>

    <?php if ($errors): ?>
        <div class="alert error"><strong>Import not completed.</strong><ul><?php foreach ($errors as $error): ?><li><?php echo admin_e($error); ?></li><?php endforeach; ?></ul></div>
    <?php endif; ?>

    <?php if ($success): ?>
        <div class="alert success"><?php echo admin_e($success); ?><?php if ($skipped): ?><br><small><?php echo count($skipped); ?> row(s) were skipped.</small><?php endif; ?></div>
    <?php endif; ?>

    <?php if ($skipped): ?>
        <section class="panel" style="margin-bottom:18px">
            <div class="panel-head"><h2>Skipped rows</h2></div>
            <div style="padding:18px 20px"><ul><?php foreach (array_slice($skipped, 0, 50) as $item): ?><li><?php echo admin_e($item); ?></li><?php endforeach; ?></ul></div>
        </section>
    <?php endif; ?>

    <section class="panel">
        <div class="panel-head"><h2>Import checker cards</h2></div>
        <form method="post" enctype="multipart/form-data" style="padding:22px">
            <input type="hidden" name="csrf" value="<?php echo admin_e(admin_csrf_token()); ?>">
            <label style="display:block;font-weight:700;font-size:13px;margin-bottom:16px">Checker product
                <select name="product_id" required style="display:block;width:100%;padding:13px;margin-top:7px;border:1px solid var(--line);border-radius:5px;background:#fff">
                    <option value="">Select product</option>
                    <?php foreach ($products as $product): ?>
                        <option value="<?php echo (int)$product['id']; ?>" <?php echo ((int)($_POST['product_id'] ?? 0) === (int)$product['id']) ? 'selected' : ''; ?>><?php echo admin_e($product['name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </label>

            <label style="display:block;font-weight:700;font-size:13px;margin-bottom:16px">CSV file
                <input type="file" name="checker_csv" accept=".csv,text/csv" style="display:block;width:100%;padding:11px;margin-top:7px;border:1px solid var(--line);border-radius:5px;background:#fff">
            </label>

            <p class="muted" style="font-size:13px;margin:-5px 0 17px">CSV format: <code>serial_number,pin</code> — one checker per row. A header row is optional.</p>

            <label style="display:block;font-weight:700;font-size:13px;margin-bottom:8px">Or paste checker rows
                <textarea name="checker_list" rows="8" placeholder="ABC123456,987654321&#10;ABC123457,987654322" style="display:block;width:100%;padding:13px;margin-top:7px;border:1px solid var(--line);border-radius:5px;resize:vertical"></textarea>
            </label>

            <div style="margin-top:18px"><button class="btn primary" type="submit">Upload Checker Cards</button></div>
        </form>
    </section>

    <section class="panel" style="margin-top:18px">
        <div class="panel-head"><h2>Example CSV</h2></div>
        <div style="padding:20px"><pre style="margin:0;white-space:pre-wrap;background:#fbfbfc;border:1px solid var(--line);padding:15px">serial_number,pin
BECE001234,123456789
BECE001235,123456790
BECE001236,123456791</pre></div>
    </section>
</main>
</div>
</body>
</html>
