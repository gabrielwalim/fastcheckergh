<?php
// FastCheckerGH Admin authentication helper.
require_once __DIR__ . '/../includes/security.php';
fc_start_secure_session('FASTCHECKERGH_ADMIN');

require_once __DIR__ . '/../includes/db.php';

function admin_csrf_token(): string
{
    if (empty($_SESSION['admin_csrf'])) {
        $_SESSION['admin_csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['admin_csrf'];
}

function admin_verify_csrf(?string $token): bool
{
    return is_string($token) && isset($_SESSION['admin_csrf']) && hash_equals($_SESSION['admin_csrf'], $token);
}

function admin_is_logged_in(): bool
{
    return !empty($_SESSION['admin_user_id']);
}

function admin_require_login(): void
{
    if (!admin_is_logged_in()) {
        header('Location: login.php');
        exit;
    }
}

function admin_logout(): void
{
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly'], $params['samesite'] ?? 'Lax');
    }
    session_destroy();
}

function admin_security_table(): void
{
    static $ready = false;
    if ($ready) return;
    $pdo = $GLOBALS['pdo'] ?? null;
    if (!$pdo instanceof PDO) return;
    try {
        $pdo->exec("CREATE TABLE IF NOT EXISTS admin_login_attempts (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            username VARCHAR(80) NOT NULL,
            ip_hash CHAR(64) NOT NULL,
            attempts INT UNSIGNED NOT NULL DEFAULT 0,
            window_started_at DATETIME NOT NULL,
            locked_until DATETIME NULL,
            PRIMARY KEY (id),
            UNIQUE KEY uq_admin_login_attempt (username, ip_hash),
            KEY idx_admin_login_locked (locked_until)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        $ready = true;
    } catch (Throwable $e) {
        error_log('FastCheckerGH admin security table: ' . $e->getMessage());
    }
}

function admin_ip_hash(): string
{
    return hash('sha256', (string)($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0'));
}

function admin_login_is_limited(string $username): bool
{
    admin_security_table();
    $pdo = $GLOBALS['pdo'] ?? null;
    if (!$pdo instanceof PDO) return false;
    try {
        $st = $pdo->prepare('SELECT locked_until FROM admin_login_attempts WHERE username = ? AND ip_hash = ? LIMIT 1');
        $st->execute([$username, admin_ip_hash()]);
        $row = $st->fetch();
        if (!$row || empty($row['locked_until'])) return false;
        $lockedUntil = strtotime((string)$row['locked_until']);
        return $lockedUntil !== false && $lockedUntil > time();
    } catch (Throwable $e) {
        error_log('FastCheckerGH login limiter read failed: ' . $e->getMessage());
        return false;
    }
}

function admin_record_login_failure(string $username): void
{
    admin_security_table();
    $pdo = $GLOBALS['pdo'] ?? null;
    if (!$pdo instanceof PDO) return;
    $ipHash = admin_ip_hash();
    try {
        $pdo->prepare('DELETE FROM admin_login_attempts WHERE locked_until IS NOT NULL AND locked_until < NOW()')->execute();
        $st = $pdo->prepare('SELECT id, attempts, window_started_at FROM admin_login_attempts WHERE username = ? AND ip_hash = ? LIMIT 1');
        $st->execute([$username, $ipHash]);
        $row = $st->fetch();
        if (!$row || strtotime((string)$row['window_started_at']) < time() - 900) {
            $pdo->prepare('INSERT INTO admin_login_attempts (username, ip_hash, attempts, window_started_at, locked_until) VALUES (?, ?, 1, NOW(), NULL) ON DUPLICATE KEY UPDATE attempts=1, window_started_at=NOW(), locked_until=NULL')->execute([$username, $ipHash]);
            return;
        }
        $attempts = (int)$row['attempts'] + 1;
        $lockedUntil = $attempts >= 5 ? date('Y-m-d H:i:s', time() + 900) : null;
        $pdo->prepare('UPDATE admin_login_attempts SET attempts = ?, locked_until = ? WHERE id = ?')->execute([$attempts, $lockedUntil, (int)$row['id']]);
    } catch (Throwable $e) {
        error_log('FastCheckerGH login limiter write failed: ' . $e->getMessage());
    }
}

function admin_clear_login_failures(string $username): void
{
    admin_security_table();
    $pdo = $GLOBALS['pdo'] ?? null;
    if (!$pdo instanceof PDO) return;
    try {
        $pdo->prepare('DELETE FROM admin_login_attempts WHERE username = ? AND ip_hash = ?')->execute([$username, admin_ip_hash()]);
    } catch (Throwable $e) {
        error_log('FastCheckerGH login limiter clear failed: ' . $e->getMessage());
    }
}

function admin_e($value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}
