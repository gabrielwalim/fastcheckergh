<?php
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/../includes/automatic-results-schema.php';

$required = [
    'user_id','order_id','result_type_id','result_type','exam_year','index_number','date_of_birth',
    'status','provider','provider_reference','voucher_id','error_message',
    'result_payload','created_at','updated_at','processed_at'
];
$columns = [];
foreach ($required as $column) {
    $columns[$column] = fc_column_exists($pdo, 'result_requests', $column);
}
$allOk = !in_array(false, $columns, true);
$stock = [];
try {
    $st = $pdo->query("SELECT p.name, COUNT(v.id) AS available FROM products p LEFT JOIN vouchers v ON v.product_id=p.id AND v.status='available' AND v.order_id IS NULL WHERE p.name IN ('BECE Checker','WASSCE Checker') GROUP BY p.id,p.name ORDER BY p.name");
    $stock = $st->fetchAll();
} catch (Throwable $e) {
    $stock = [];
}
?>
<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Automatic Results Setup</title><link rel="stylesheet" href="admin.css"></head>
<body>
<div class="admin-shell">
<div class="admin-content">
<h1>Automatic Results Setup</h1>
<p>This page verifies and repairs the database structure required by the automatic purchase flow.</p>
<div class="card" style="padding:20px;margin-top:20px">
<p><strong><?php echo $allOk ? 'Automatic Results database is ready.' : 'Some required columns are still missing.'; ?></strong></p>
<h2 style="margin-top:20px">Checker stock</h2><table class="admin-table" style="margin-top:10px"><thead><tr><th>Product</th><th>Available</th></tr></thead><tbody><?php foreach ($stock as $row): ?><tr><td><?php echo htmlspecialchars($row['name'], ENT_QUOTES, 'UTF-8'); ?></td><td><?php echo (int)$row['available']; ?></td></tr><?php endforeach; ?><?php if (!$stock): ?><tr><td colspan="2">No BECE/WASSCE checker products found.</td></tr><?php endif; ?></tbody></table>
<table class="admin-table" style="margin-top:15px"><thead><tr><th>Column</th><th>Status</th></tr></thead><tbody>
<?php foreach ($columns as $column => $ok): ?><tr><td><?php echo htmlspecialchars($column, ENT_QUOTES, 'UTF-8'); ?></td><td><?php echo $ok ? 'OK' : 'MISSING'; ?></td></tr><?php endforeach; ?>
</tbody></table>
</div>
<p style="margin-top:20px"><a href="index.php">← Back to Admin Dashboard</a></p>
</div></div>
</body></html>
