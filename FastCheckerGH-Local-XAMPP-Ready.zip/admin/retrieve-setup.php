<?php
require_once __DIR__.'/../includes/env.php';
require_once __DIR__.'/../includes/db.php';
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
$ok=true; $messages=[];
try {
  $tables=$pdo->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN);
  foreach(['users','orders','order_items','products','vouchers'] as $t){
    $has=in_array($t,$tables,true); $ok=$ok&&$has; $messages[]=$t.': '.($has?'OK':'MISSING');
  }
  $messages[]='OTP storage: PHP session (no checker_otps table required)';
} catch(Throwable $e){$ok=false;$messages[]='Database error: '.$e->getMessage();}
?><!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Retrieve Setup - FastCheckerGH</title><link rel="stylesheet" href="admin.css"></head><body class="admin-body"><div class="admin-main" style="max-width:800px;margin:auto"><h1>Retrieve Old Checkers Setup</h1><p>This check confirms the existing purchase tables required by retrieval. OTPs are stored temporarily in the PHP session, so no new OTP table is required.</p><div class="alert <?php echo $ok?'success':'error'; ?>"><?php echo $ok?'Retrieve system prerequisites are ready.':'One or more required tables are missing.'; ?></div><pre style="background:#f7f8fa;padding:20px;border:1px solid #e7e8ec;line-height:1.7"><?php echo htmlspecialchars(implode("\n",$messages),ENT_QUOTES,'UTF-8'); ?></pre><p><a class="btn primary" href="../retrieve.php">Open Retrieve Old Checkers</a></p></div></body></html>