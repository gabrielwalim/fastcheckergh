<?php
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/../config/paystack.php';

admin_require_login();

$csrfToken = admin_csrf_token();
$result = null;

function paystack_test_message_from_http(int $httpStatus, array $response): string
{
    if ($httpStatus === 401) {
        return 'Paystack rejected the secret key. Check that PAYSTACK_SECRET_KEY is correct and matches Test/Live mode.';
    }

    if ($httpStatus === 403) {
        return 'Paystack denied access to this API request. Check your account/API key permissions.';
    }

    if ($httpStatus >= 500) {
        return 'Paystack returned a server-side error. Try again shortly.';
    }

    if (isset($response['message']) && is_string($response['message']) && $response['message'] !== '') {
        return $response['message'];
    }

    return 'Paystack returned an unexpected response.';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $submittedToken = $_POST['csrf_token'] ?? null;

    if (!admin_verify_csrf($submittedToken)) {
        $result = [
            'ok' => false,
            'title' => 'Security check failed',
            'message' => 'Refresh the page and try the connection test again.',
            'http_status' => null,
            'curl_error' => null,
        ];
    } elseif ($paystackSecretKey === '') {
        $result = [
            'ok' => false,
            'title' => 'Secret key is not configured',
            'message' => 'Set PAYSTACK_SECRET_KEY on the server, then restart Apache/PHP and test again.',
            'http_status' => null,
            'curl_error' => null,
        ];
    } elseif (!function_exists('curl_init')) {
        $result = [
            'ok' => false,
            'title' => 'PHP cURL is not enabled',
            'message' => 'Enable the cURL extension in your XAMPP PHP configuration and restart Apache.',
            'http_status' => null,
            'curl_error' => null,
        ];
    } else {
        $url = rtrim($paystackApiUrl, '/') . '/balance';
        $ch = curl_init($url);

        curl_setopt_array($ch, [
            CURLOPT_HTTPGET => true,
            CURLOPT_HTTPHEADER => [
                'Authorization: Bearer ' . $paystackSecretKey,
                'Accept: application/json',
            ],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_TIMEOUT => 20,
        ]);

        $responseBody = curl_exec($ch);
        $curlError = $responseBody === false ? curl_error($ch) : null;
        $httpStatus = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($responseBody === false) {
            $friendly = 'Unable to reach Paystack.';
            if (is_string($curlError) && $curlError !== '') {
                if (stripos($curlError, 'Could not resolve host') !== false) {
                    $friendly = 'DNS could not resolve api.paystack.co. Check your internet connection, DNS settings, firewall, proxy, or hosting network.';
                } elseif (stripos($curlError, 'SSL') !== false || stripos($curlError, 'certificate') !== false) {
                    $friendly = 'The HTTPS/SSL connection to Paystack failed. Check your server certificate/CA configuration and system date/time.';
                } elseif (stripos($curlError, 'timed out') !== false) {
                    $friendly = 'The connection to Paystack timed out. Check your network, firewall, proxy, or hosting provider.';
                }
            }

            error_log('FastCheckerGH Paystack connection test failed: ' . (string)$curlError);
            $result = [
                'ok' => false,
                'title' => 'Connection failed',
                'message' => $friendly,
                'http_status' => null,
                'curl_error' => $curlError,
            ];
        } else {
            $decoded = json_decode($responseBody, true);
            if (!is_array($decoded)) {
                error_log('FastCheckerGH Paystack connection test returned invalid JSON: ' . $responseBody);
                $result = [
                    'ok' => false,
                    'title' => 'Invalid Paystack response',
                    'message' => 'Paystack responded, but the response was not valid JSON.',
                    'http_status' => $httpStatus,
                    'curl_error' => null,
                ];
            } elseif ($httpStatus >= 200 && $httpStatus < 300 && ($decoded['status'] ?? false) === true) {
                $result = [
                    'ok' => true,
                    'title' => 'Paystack connection successful',
                    'message' => 'FastCheckerGH reached Paystack and authenticated successfully.',
                    'http_status' => $httpStatus,
                    'curl_error' => null,
                ];
            } else {
                $result = [
                    'ok' => false,
                    'title' => 'Paystack connection reached the API',
                    'message' => paystack_test_message_from_http($httpStatus, $decoded),
                    'http_status' => $httpStatus,
                    'curl_error' => null,
                ];
            }
        }
    }
}

$maskedKey = $paystackSecretKey === ''
    ? 'Not configured'
    : substr($paystackSecretKey, 0, 8) . '••••••••' . substr($paystackSecretKey, -4);
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Paystack Connection - FastCheckerGH</title>
<link rel="stylesheet" href="admin.css">
</head>
<body class="admin-body">
<header class="admin-topbar">
    <a class="admin-brand" href="index.php"><span>FastChecker</span><b>GH</b></a>
    <div class="admin-user"><span><?php echo admin_e($_SESSION['admin_name'] ?? 'Administrator'); ?></span><a href="logout.php">Logout</a></div>
</header>
<div class="admin-shell">
    <aside class="admin-sidebar">
        <a href="index.php">Dashboard</a>
        <a href="orders.php">Orders & Payments</a>
        <a href="vouchers.php">Voucher Inventory</a>
        <a href="users.php">Customers</a>
        <a href="results.php">Result Requests</a>
        <a href="notifications.php">Notifications</a><a href="delivery-test.php">Delivery Test</a>
        <a href="paystack-settings.php">Paystack Settings</a>
        <a class="active" href="paystack-test.php">Paystack Connection</a>
        <a href="export-orders.php">Export Orders</a>
        <a href="../index.php">View Website</a>
    </aside>
    <main class="admin-main">
        <div class="page-title">
            <div>
                <p class="eyebrow">PAYMENTS</p>
                <h1>Paystack Connection</h1>
                <p class="muted">Test the server's DNS, HTTPS connection and Paystack authentication without creating a payment.</p>
            </div>
        </div>

        <?php if ($result): ?>
            <div class="alert <?php echo $result['ok'] ? 'success' : 'error'; ?>">
                <strong><?php echo admin_e($result['title']); ?></strong>
                <div style="margin-top:6px"><?php echo admin_e($result['message']); ?></div>
                <?php if (!empty($result['http_status'])): ?>
                    <div style="margin-top:8px;font-size:13px">HTTP status: <strong><?php echo (int)$result['http_status']; ?></strong></div>
                <?php endif; ?>
                <?php if (!empty($result['curl_error'])): ?>
                    <div style="margin-top:8px;font-size:13px">cURL: <code><?php echo admin_e($result['curl_error']); ?></code></div>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <div style="margin-bottom:18px"><a class="btn" href="paystack-settings.php">Open Paystack Settings</a></div>

        <section class="panel">
            <div class="panel-head"><h2>Current configuration</h2></div>
            <div style="padding:22px">
                <div class="table-wrap">
                    <table>
                        <tbody>
                            <tr><th>Paystack API URL</th><td><?php echo admin_e($paystackApiUrl); ?></td></tr>
                            <tr><th>Secret key</th><td><?php echo admin_e($maskedKey); ?></td></tr>
                            <tr><th>Currency</th><td>GHS</td></tr>
                            <tr><th>Test endpoint</th><td><code><?php echo admin_e(rtrim($paystackApiUrl, '/') . '/balance'); ?></code></td></tr>
                        </tbody>
                    </table>
                </div>
                <form method="post" style="margin-top:20px">
                    <input type="hidden" name="csrf_token" value="<?php echo admin_e($csrfToken); ?>">
                    <button class="btn primary" type="submit">Test Paystack Connection</button>
                </form>
            </div>
        </section>

        <section class="panel" style="margin-top:18px">
            <div class="panel-head"><h2>What this test checks</h2></div>
            <div style="padding:22px;color:var(--muted);line-height:1.7">
                <p style="margin:0 0 8px">1. The Paystack API hostname can be resolved by your server.</p>
                <p style="margin:0 0 8px">2. Your server can establish an HTTPS connection to Paystack.</p>
                <p style="margin:0 0 8px">3. The configured secret key is accepted by Paystack.</p>
                <p style="margin:0">4. The test does <strong>not</strong> create a customer payment or charge.</p>
            </div>
        </section>
    </main>
</div>
</body>
</html>
