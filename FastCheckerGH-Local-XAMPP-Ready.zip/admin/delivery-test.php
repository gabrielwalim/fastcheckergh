<?php
require_once __DIR__ . '/auth.php';
admin_require_login();
require_once __DIR__ . '/../includes/result-delivery.php';

$message = '';
$errors = [];
$results = [];
$channel = (string)($_POST['channel'] ?? 'email');
$email = trim((string)($_POST['email'] ?? ''));
$phone = trim((string)($_POST['phone'] ?? ''));
$csrf = (string)($_POST['csrf_token'] ?? '');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!admin_verify_csrf($csrf)) {
        $errors[] = 'Invalid security token. Refresh the page and try again.';
    } else {
        try {
            fc_ensure_notification_logs_table($pdo);

            switch ($channel) {
                case 'email':
                    $html = '<div style="font-family:Arial,sans-serif"><h2>FastCheckerGH delivery test</h2><p>This is a test transactional email from your FastCheckerGH admin dashboard.</p></div>';
                    $res = fc_send_brevo_email($pdo, $email, 'FastCheckerGH Delivery Test', $html, null, null, filter_var((string)(getenv('BREVO_EMAIL_SANDBOX') ?: '0'), FILTER_VALIDATE_BOOLEAN));
                    $results[] = ['channel' => 'Email', 'result' => $res];
                    break;
                case 'sms':
                    $res = fc_send_brevo_sms($pdo, $phone, 'FastCheckerGH: This is a test SMS delivery from your admin dashboard.');
                    $results[] = ['channel' => 'SMS', 'result' => $res];
                    break;
                case 'whatsapp':
                    $res = fc_send_brevo_whatsapp($pdo, $phone, 'FastCheckerGH: This is a test WhatsApp message from your admin dashboard.', ['Admin Test']);
                    $results[] = ['channel' => 'WhatsApp', 'result' => $res];
                    break;
                default:
                    $errors[] = 'Unsupported delivery channel.';
            }
        } catch (Throwable $e) {
            error_log('FastCheckerGH delivery test failed: ' . $e->getMessage());
            $errors[] = fc_debug_enabled() ? $e->getMessage() : 'The delivery test failed. Check the server logs.';
        }
    }
}

function delivery_config_status(): array
{
    return [
        'Brevo API key' => getenv('BREVO_API_KEY') !== false && trim((string)getenv('BREVO_API_KEY')) !== '',
        'Email sender' => filter_var((string)getenv('BREVO_EMAIL_SENDER'), FILTER_VALIDATE_EMAIL) !== false,
        'SMS sender' => trim((string)getenv('BREVO_SMS_SENDER')) !== '',
        'WhatsApp sender' => trim((string)getenv('BREVO_WHATSAPP_SENDER')) !== '',
        'WhatsApp template' => ctype_digit(trim((string)getenv('BREVO_WHATSAPP_TEMPLATE_ID'))),
    ];
}
$config = delivery_config_status();
?><!doctype html>
<html lang="en">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Delivery Test - FastCheckerGH</title><link rel="stylesheet" href="admin.css"></head>
<body class="admin-body">
<header class="admin-topbar"><a class="admin-brand" href="index.php"><span>FastChecker</span><b>GH</b></a><div class="admin-user"><span><?php echo admin_e($_SESSION['admin_name'] ?? 'Administrator'); ?></span><a href="logout.php">Logout</a></div></header>
<div class="admin-shell">
<aside class="admin-sidebar">
<a href="index.php">Dashboard</a><a href="orders.php">Orders & Payments</a><a href="vouchers.php">Voucher Inventory</a><a href="upload-vouchers.php">Upload Checkers</a><a href="users.php">Customers</a><a href="results.php">Result Requests</a><a href="notifications.php">Notifications</a><a href="delivery-test.php" class="active">Delivery Test</a><a href="paystack-test.php">Paystack Connection</a><a href="export-orders.php">Export Orders</a><a href="../index.php">View Website</a>
</aside>
<main class="admin-main">
<div class="page-title"><div><p class="eyebrow">MESSAGING</p><h1>SMS / WhatsApp / Email Test</h1><p class="muted">Verify the Brevo delivery configuration before real result notifications are sent.</p></div></div>
<?php foreach($errors as $error): ?><div class="alert error"><?php echo admin_e($error); ?></div><?php endforeach; ?>
<?php foreach($results as $item): $ok=!empty($item['result']['success']); ?><div class="alert <?php echo $ok ? 'success' : 'error'; ?>"><strong><?php echo admin_e($item['channel']); ?>:</strong> <?php echo admin_e((string)($item['result']['message'] ?? ($ok ? 'Sent successfully.' : 'Delivery failed.'))); ?><?php if($ok && !empty($item['result']['data']['messageId'])): ?> <code><?php echo admin_e($item['result']['data']['messageId']); ?></code><?php endif; ?></div><?php endforeach; ?>
<section class="panel" style="margin-bottom:18px"><div class="panel-head"><h2>Configuration status</h2><a href="notifications.php">View logs</a></div><div class="stock-list"><?php foreach($config as $label=>$ready): ?><div class="stock-row"><div><?php echo admin_e($label); ?></div><strong class="badge <?php echo $ready ? 'sent' : 'failed'; ?>"><?php echo $ready ? 'Configured' : 'Missing'; ?></strong></div><?php endforeach; ?></div></section>
<section class="panel"><div class="panel-head"><h2>Send a test message</h2></div><div style="padding:20px">
<form method="post" style="display:grid;gap:15px;max-width:680px">
<input type="hidden" name="csrf_token" value="<?php echo admin_e(admin_csrf_token()); ?>">
<label>Channel<select name="channel" id="delivery-channel" style="display:block;width:100%;padding:12px;border:1px solid #dfe2e8;border-radius:5px;margin-top:7px"><option value="email" <?php echo $channel==='email'?'selected':''; ?>>Email</option><option value="sms" <?php echo $channel==='sms'?'selected':''; ?>>SMS</option><option value="whatsapp" <?php echo $channel==='whatsapp'?'selected':''; ?>>WhatsApp</option></select></label>
<label id="email-field">Email<input name="email" value="<?php echo admin_e($email); ?>" placeholder="customer@example.com" style="display:block;width:100%;padding:12px;border:1px solid #dfe2e8;border-radius:5px;margin-top:7px"></label>
<label id="phone-field">Mobile number<input name="phone" value="<?php echo admin_e($phone); ?>" placeholder="0551234567 or +233551234567" style="display:block;width:100%;padding:12px;border:1px solid #dfe2e8;border-radius:5px;margin-top:7px"></label>
<button class="btn primary" type="submit">Send Test Message</button>
</form>
<p class="muted" style="margin-top:14px;font-size:12px">For email, enable <code>BREVO_EMAIL_SANDBOX=1</code> in local testing to validate the request without sending an email. Actual SMS/WhatsApp delivery requires the corresponding Brevo services and account setup.</p>
</div></section>
</main></div>
<script>
(function(){const c=document.getElementById('delivery-channel');const e=document.getElementById('email-field');const p=document.getElementById('phone-field');function sync(){const v=c.value;e.style.display=v==='email'?'block':'none';p.style.display=v==='email'?'none':'block';}c.addEventListener('change',sync);sync();})();
</script>
</body></html>
