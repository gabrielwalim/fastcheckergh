// ==========================================
// FASTCHECKERGH - BECE CHECKER
// Checkout + Payment JavaScript
// ==========================================


// ------------------------------------------
// Get product information from PHP
// ------------------------------------------

const priceElement =
    document.getElementById("product-price");

const productIdElement =
    document.getElementById("product-id");


// ------------------------------------------
// Check product information
// ------------------------------------------

if (!priceElement || !productIdElement) {

    console.error(
        "Product information could not be found."
    );

    throw new Error(
        "Product information is missing."
    );

}


// ------------------------------------------
// Get product information
// ------------------------------------------

const unitPrice =
    Number(priceElement.dataset.price);

const productId =
    Number(productIdElement.value);


// ------------------------------------------
// Get page elements
// ------------------------------------------

const quantityInput =
    document.getElementById("quantity");

const increaseButton =
    document.getElementById("increase");

const decreaseButton =
    document.getElementById("decrease");

const totalPrice =
    document.getElementById("total-price");

const checkoutButton =
    document.getElementById("checkout-button");


// ------------------------------------------
// Check required elements
// ------------------------------------------

if (
    !quantityInput ||
    !increaseButton ||
    !decreaseButton ||
    !totalPrice ||
    !checkoutButton
) {

    console.error(
        "One or more checkout elements are missing."
    );

    throw new Error(
        "Checkout elements are missing."
    );

}


// ------------------------------------------
// Update total
// ------------------------------------------

function updateTotal() {

    const quantity =
        Number(quantityInput.value);

    const total =
        unitPrice * quantity;

    totalPrice.textContent =
        total.toFixed(2);

}


// ------------------------------------------
// Increase quantity
// ------------------------------------------

increaseButton.addEventListener(
    "click",
    function () {

        let quantity =
            Number(quantityInput.value);

        if (quantity < 10) {

            quantity++;

            quantityInput.value =
                quantity;

            updateTotal();

        }

    }
);


// ------------------------------------------
// Decrease quantity
// ------------------------------------------

decreaseButton.addEventListener(
    "click",
    function () {

        let quantity =
            Number(quantityInput.value);

        if (quantity > 1) {

            quantity--;

            quantityInput.value =
                quantity;

            updateTotal();

        }

    }
);


// ------------------------------------------
// Checkout
// ------------------------------------------

checkoutButton.addEventListener(
    "click",
    async function () {

        // ----------------------------------
        // Get customer information
        // ----------------------------------

        const quantity =
            Number(quantityInput.value);

        const phone =
            document
                .getElementById("phone")
                .value
                .trim();

        const email =
            document
                .getElementById("email")
                .value
                .trim();


        // ----------------------------------
        // Validate quantity
        // ----------------------------------

        if (
            quantity < 1 ||
            quantity > 10
        ) {

            alert(
                "Please select a quantity between 1 and 10."
            );

            return;

        }


        // ----------------------------------
        // Validate phone
        // ----------------------------------

        if (phone === "") {

            alert(
                "Please enter your Mobile Money number."
            );

            return;

        }


        // ----------------------------------
        // Validate email
        // ----------------------------------

        if (email === "") {

            alert(
                "Please enter your email address."
            );

            return;

        }


        // ----------------------------------
        // Validate product ID
        // ----------------------------------

        if (
            !Number.isInteger(productId) ||
            productId <= 0
        ) {

            alert(
                "Invalid product information."
            );

            return;

        }


        // ----------------------------------
        // Disable button
        // ----------------------------------

        checkoutButton.disabled = true;

        checkoutButton.textContent =
            "Creating Order...";


        try {

            // ==================================
            // STEP 1
            // CREATE ORDER
            // ==================================

            const orderResponse =
                await fetch(
                    "api/create-order.php",
                    {
                        method: "POST",

                        headers: {
                            "Content-Type":
                                "application/json"
                        },

                        body: JSON.stringify({

                            product_id:
                                productId,

                            quantity:
                                quantity,

                            phone:
                                phone,

                            email:
                                email

                        })
                    }
                );


            // ----------------------------------
            // Read response
            // ----------------------------------

            const orderResult =
                await orderResponse.json();


            // ----------------------------------
            // Check order creation
            // ----------------------------------

            if (
                !orderResponse.ok ||
                !orderResult.success
            ) {

                throw new Error(
                    orderResult.message ||
                    "Unable to create order."
                );

            }


            // ----------------------------------
            // Get order ID
            // ----------------------------------

            const orderId =
                orderResult.order_id;


            console.log(
                "Order created:",
                orderId
            );


            // ==================================
            // STEP 2
            // INITIALIZE PAYMENT
            // ==================================

            checkoutButton.textContent =
                "Connecting to Payment...";


            const paymentResponse =
                await fetch(
                    "api/initialize-payment.php",
                    {
                        method: "POST",

                        headers: {
                            "Content-Type":
                                "application/json"
                        },

                        body: JSON.stringify({

                            order_id:
                                orderId

                        })
                    }
                );


            // ----------------------------------
            // Read payment response
            // ----------------------------------

            const paymentResult =
                await paymentResponse.json();


            // ----------------------------------
            // Check payment initialization
            // ----------------------------------

            if (
                !paymentResponse.ok ||
                !paymentResult.success
            ) {

                throw new Error(
                    paymentResult.message ||
                    "Unable to initialize payment."
                );

            }


            // ==================================
            // STEP 3
            // SEND CUSTOMER TO PAYSTACK
            // ==================================

            if (
                !paymentResult.authorization_url
            ) {

                throw new Error(
                    "Payment URL was not received."
                );

            }


            checkoutButton.textContent =
                "Redirecting to Payment...";


            // ----------------------------------
            // Redirect to Paystack
            // ----------------------------------

            window.location.href =
                paymentResult.authorization_url;


        } catch (error) {

            // ----------------------------------
            // Display error
            // ----------------------------------

            console.error(
                "Checkout error:",
                error
            );


            alert(
                "Something went wrong.\n\n" +
                error.message
            );


            // ----------------------------------
            // Restore button
            // ----------------------------------

            checkoutButton.disabled =
                false;

            checkoutButton.textContent =
                "Proceed to Checkout";

        }

    }
);


// ------------------------------------------
// Calculate total on page load
// ------------------------------------------

updateTotal();