// ==========================================
// FASTCHECKERGH - WASSCE CHECKER
// Checkout + Payment JavaScript
// ==========================================

// Get product information from PHP
const priceElement =
    document.getElementById("product-price");

const productIdElement =
    document.getElementById("product-id");

if (!priceElement || !productIdElement) {
    console.error("Product information could not be found.");
    throw new Error("Product information is missing.");
}

const unitPrice =
    Number(priceElement.dataset.price);

const productId =
    Number(productIdElement.value);


// ==========================================
// GET CHECKOUT ELEMENTS
// ==========================================

const quantityInput =
    document.getElementById("quantity");

const increaseButton =
    document.getElementById("increase");

const decreaseButton =
    document.getElementById("decrease");

const totalPrice =
    document.getElementById("total-price");

const checkoutButton =
    document.getElementById("checkout-button");


// Check that all required elements exist
if (
    !quantityInput ||
    !increaseButton ||
    !decreaseButton ||
    !totalPrice ||
    !checkoutButton
) {
    console.error("One or more checkout elements are missing.");
    throw new Error("Checkout elements are missing.");
}


// ==========================================
// UPDATE TOTAL PRICE
// ==========================================

function updateTotal() {

    const quantity =
        Number(quantityInput.value);

    const total =
        unitPrice * quantity;

    totalPrice.textContent =
        total.toFixed(2);
}


// ==========================================
// INCREASE QUANTITY
// ==========================================

increaseButton.addEventListener(
    "click",
    function () {

        let quantity =
            Number(quantityInput.value);

        if (quantity < 10) {

            quantity++;

            quantityInput.value =
                quantity;

            updateTotal();
        }
    }
);


// ==========================================
// DECREASE QUANTITY
// ==========================================

decreaseButton.addEventListener(
    "click",
    function () {

        let quantity =
            Number(quantityInput.value);

        if (quantity > 1) {

            quantity--;

            quantityInput.value =
                quantity;

            updateTotal();
        }
    }
);


// ==========================================
// CHECKOUT BUTTON
// ==========================================

checkoutButton.addEventListener(
    "click",
    async function () {

        const quantity =
            Number(quantityInput.value);

        const phone =
            document
                .getElementById("phone")
                .value
                .trim();

        const email =
            document
                .getElementById("email")
                .value
                .trim();


        // ==========================================
        // VALIDATE QUANTITY
        // ==========================================

        if (
            quantity < 1 ||
            quantity > 10
        ) {

            alert(
                "Please select a quantity between 1 and 10."
            );

            return;
        }


        // ==========================================
        // VALIDATE PHONE
        // ==========================================

        if (phone === "") {

            alert(
                "Please enter your Mobile Money number."
            );

            return;
        }


        // ==========================================
        // VALIDATE EMAIL
        // ==========================================

        if (email === "") {

            alert(
                "Please enter your email address."
            );

            return;
        }


        // ==========================================
        // VALIDATE PRODUCT
        // ==========================================

        if (
            !Number.isInteger(productId) ||
            productId <= 0
        ) {

            alert(
                "Invalid product information."
            );

            return;
        }


        // Disable button while processing
        checkoutButton.disabled = true;

        checkoutButton.textContent =
            "Creating Order...";


        try {

            // ==========================================
            // STEP 1: CREATE ORDER
            // ==========================================

            const orderResponse =
                await fetch(
                    "api/create-order.php",
                    {
                        method: "POST",

                        headers: {
                            "Content-Type":
                                "application/json"
                        },

                        body: JSON.stringify({

                            product_id:
                                productId,

                            quantity:
                                quantity,

                            phone:
                                phone,

                            email:
                                email
                        })
                    }
                );


            const orderResult =
                await orderResponse.json();
                console.log("ORDER RESPONSE:", orderResult);


            if (
                !orderResponse.ok ||
                !orderResult.success
            ) {

                throw new Error(
                    orderResult.message ||
                    "Unable to create order."
                );
            }


            // Get the newly created order ID
            const orderId =
                orderResult.order_id;


            console.log(
                "WASSCE Order created:",
                orderId
            );


            // ==========================================
            // STEP 2: INITIALIZE PAYMENT
            // ==========================================

            checkoutButton.textContent =
                "Connecting to Payment...";


            const paymentResponse =
                await fetch(
                    "api/initialize-payment.php",
                    {
                        method: "POST",

                        headers: {
                            "Content-Type":
                                "application/json"
                        },

                        body: JSON.stringify({

                            order_id:
                                orderId
                        })
                    }
                );


            const paymentResult =
                await paymentResponse.json();
                console.log("PAYMENT RESPONSE:", paymentResult);


            if (
                !paymentResponse.ok ||
                !paymentResult.success
            ) {

                throw new Error(
                    paymentResult.message ||
                    "Unable to initialize payment."
                );
            }


            // ==========================================
            // CHECK PAYMENT URL
            // ==========================================

            if (
                !paymentResult.authorization_url
            ) {

                throw new Error(
                    "Payment URL was not received."
                );
            }


            // ==========================================
            // STEP 3: REDIRECT TO PAYSTACK
            // ==========================================

            checkoutButton.textContent =
                "Redirecting to Payment...";


            window.location.href =
                paymentResult.authorization_url;


        } catch (error) {

            console.error(
                "WASSCE checkout error:",
                error
            );


            alert(
                "Something went wrong.\n\n" +
                error.message
            );


            // Re-enable checkout button
            checkoutButton.disabled =
                false;

            checkoutButton.textContent =
                "Proceed to Checkout";
        }
    }
);


// ==========================================
// INITIAL PRICE CALCULATION
// ==========================================

updateTotal();