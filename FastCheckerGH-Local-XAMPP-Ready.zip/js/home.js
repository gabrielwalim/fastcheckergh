(function () {
    const modals = document.querySelectorAll('.modal');

    function openModal(id) {
        const modal = document.getElementById(id);
        if (!modal) return;
        modal.classList.add('is-open');
        modal.setAttribute('aria-hidden', 'false');
        document.body.classList.add('modal-open');
        const firstField = modal.querySelector('select, input, button');
        if (firstField) setTimeout(() => firstField.focus(), 50);
    }

    function closeModal(modal) {
        modal.classList.remove('is-open');
        modal.setAttribute('aria-hidden', 'true');
        if (!document.querySelector('.modal.is-open')) document.body.classList.remove('modal-open');
    }

    document.querySelectorAll('[data-open-modal]').forEach(button => {
        button.addEventListener('click', () => openModal(button.dataset.openModal));
    });

    document.querySelectorAll('[data-close-modal]').forEach(button => {
        button.addEventListener('click', () => closeModal(button.closest('.modal')));
    });

    document.addEventListener('keydown', event => {
        if (event.key === 'Escape') {
            const open = document.querySelector('.modal.is-open');
            if (open) closeModal(open);
        }
    });

    const quantity = document.getElementById('checker-quantity');
    document.querySelectorAll('[data-quantity]').forEach(button => {
        button.addEventListener('click', () => {
            let value = parseInt(quantity.value || '1', 10);
            value += button.dataset.quantity === 'plus' ? 1 : -1;
            quantity.value = Math.max(1, Math.min(200, value));
        });
    });

    document.getElementById('continue-buy')?.addEventListener('click', () => {
        const destination = document.getElementById('checker-type').value;
        if (!destination) {
            alert('Please select a checker type.');
            return;
        }
        const qty = document.getElementById('checker-quantity').value;
        window.location.href = destination + '?quantity=' + encodeURIComponent(qty);
    });

    document.getElementById('continue-check')?.addEventListener('click', () => {
        const type = document.getElementById('result-type-home').value;
        if (!type) {
            alert('Please select a result type.');
            return;
        }
        window.location.href = 'automatic-results.php?type=' + encodeURIComponent(type);
    });
})();
