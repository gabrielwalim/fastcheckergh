-- FastCheckerGH Automatic Results Checker
-- This migration is also applied automatically by includes/automatic-results-schema.php.

CREATE TABLE IF NOT EXISTS result_types (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    name VARCHAR(150) NOT NULL,
    code VARCHAR(80) NOT NULL,
    description VARCHAR(255) NULL,
    status ENUM('active','inactive') NOT NULL DEFAULT 'active',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_result_type_code (code),
    KEY idx_result_types_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO result_types (name, code, description, status) VALUES
('BECE','bece','Basic Education Certificate Examination','active'),
('WASSCE School','wassce-school','WASSCE - School Candidates','active'),
('WASSCE Private','wassce-private','WASSCE - Private Candidates','active')
ON DUPLICATE KEY UPDATE name=VALUES(name), description=VALUES(description), status='active';

CREATE TABLE IF NOT EXISTS result_requests (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id INT UNSIGNED NULL,
    result_type VARCHAR(80) NOT NULL,
    exam_year VARCHAR(10) NOT NULL,
    index_number VARCHAR(80) NOT NULL,
    date_of_birth DATE NULL,
    status VARCHAR(40) NOT NULL DEFAULT 'pending',
    provider VARCHAR(80) NULL,
    provider_reference VARCHAR(191) NULL,
    voucher_id BIGINT UNSIGNED NULL,
    error_message TEXT NULL,
    result_payload LONGTEXT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    processed_at DATETIME NULL,
    PRIMARY KEY (id),
    KEY idx_result_requests_status (status),
    KEY idx_result_requests_type_year (result_type, exam_year),
    KEY idx_result_requests_index (index_number),
    KEY idx_result_requests_user (user_id),
    KEY idx_result_requests_voucher (voucher_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Link an automatic result request to the checker purchase order.
ALTER TABLE result_requests ADD COLUMN order_id BIGINT UNSIGNED NULL AFTER user_id;
ALTER TABLE result_requests ADD KEY idx_result_requests_order (order_id);
