<?php

require_once __DIR__ . '/../includes/env.php';

// ==========================================
// FASTCHECKERGH - PAYSTACK CONFIGURATION
// ==========================================
// IMPORTANT:
// Keep the secret key on the server only.
// Set these values as environment variables in production:
//   PAYSTACK_SECRET_KEY=sk_test_...
//   PAYSTACK_API_URL=https://api.paystack.co
//   FASTCHECKERGH_SITE_URL=https://your-domain.com
// ==========================================

$paystackSecretKey = trim((string) getenv('PAYSTACK_SECRET_KEY'));

// Normalize common configuration mistakes. Store ONLY the raw Paystack secret
// key in PAYSTACK_SECRET_KEY.
// Do not store "Authorization: Bearer ..." or "Bearer ..." in the variable.
$paystackSecretKey = preg_replace('/^\s*Authorization\s*:\s*/i', '', $paystackSecretKey);
$paystackSecretKey = preg_replace('/^\s*Bearer\s+/i', '', $paystackSecretKey);
$paystackSecretKey = trim((string) $paystackSecretKey);

// Reject accidental public keys or malformed values before making an API call.
if ($paystackSecretKey !== '' && !preg_match('/^sk_(test|live)_[A-Za-z0-9]+$/', $paystackSecretKey)) {
    error_log('FastCheckerGH: PAYSTACK_SECRET_KEY must be a secret key beginning with sk_test_ or sk_live_.');
    $paystackSecretKey = '';
}

// Paystack's official API base URL. Do not change this to api.paystck.co.
$paystackApiUrl = trim((string) (getenv('PAYSTACK_API_URL') ?: 'https://api.paystack.co'));

$paystackCurrency = 'GHS';

$siteUrl = rtrim(
    trim((string) (getenv('FASTCHECKERGH_SITE_URL') ?: 'http://localhost/fastcheckergh')),
    '/'
);

$paymentCallbackUrl = $siteUrl . '/payment-success.php';

// Fail early with a clear server-side configuration error.
if ($paystackSecretKey === '') {
    error_log('FastCheckerGH: PAYSTACK_SECRET_KEY is not configured.');
}

// Prevent an accidental misspelling such as api.paystck.co from being used.
$parsedPaystackUrl = parse_url($paystackApiUrl);
if (
    !is_array($parsedPaystackUrl) ||
    ($parsedPaystackUrl['scheme'] ?? '') !== 'https' ||
    ($parsedPaystackUrl['host'] ?? '') !== 'api.paystack.co'
) {
    error_log('FastCheckerGH: Invalid Paystack API URL. Expected https://api.paystack.co');
    $paystackApiUrl = 'https://api.paystack.co';
}
