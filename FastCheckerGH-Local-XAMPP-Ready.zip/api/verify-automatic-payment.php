<?php
// FastCheckerGH - verify an automatic-results payment and assign its checker.
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/automatic-results-schema.php';
require_once __DIR__ . '/../config/paystack.php';

function fc_auto_json(bool $success, string $message, array $data = [], int $code = 200): void {
    http_response_code($code);
    header('Content-Type: application/json; charset=UTF-8');
    echo json_encode(array_merge(['success'=>$success,'message'=>$message], $data));
    exit;
}

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    fc_auto_json(false, 'Method not allowed.', [], 405);
}

$body = json_decode((string)file_get_contents('php://input'), true);
if (!is_array($body)) {
    fc_auto_json(false, 'Invalid request data.', [], 400);
}

$reference = trim((string)($body['reference'] ?? ''));
$requestId = (int)($body['request_id'] ?? 0);
if ($reference === '' || $requestId <= 0) {
    fc_auto_json(false, 'Payment reference and result request are required.', [], 400);
}

try {
    $stmt = $pdo->prepare("SELECT rr.id, rr.order_id, rr.result_type, rr.exam_year, rr.index_number, rr.status AS request_status, rr.voucher_id, o.status AS order_status, o.total_amount, pmt.id AS payment_id, pmt.payment_reference, pmt.amount AS payment_amount, pmt.status AS payment_status, oi.product_id, oi.quantity, prod.name AS product_name FROM result_requests rr INNER JOIN orders o ON o.id = rr.order_id INNER JOIN order_items oi ON oi.order_id = o.id INNER JOIN products prod ON prod.id = oi.product_id LEFT JOIN payments pmt ON pmt.order_id = o.id AND pmt.payment_reference = ? WHERE rr.id = ? LIMIT 1");
    $stmt->execute([$reference, $requestId]);
    $ctx = $stmt->fetch();
    if (!$ctx) {
        fc_auto_json(false, 'Automatic result request or payment record was not found.', [], 404);
    }

    $expected = (int)round((float)$ctx['total_amount'] * 100);
    $needExternalVerification = (($ctx['payment_status'] ?? '') !== 'successful');

    if ($needExternalVerification) {
        if ($paystackSecretKey === '') {
            fc_auto_json(false, 'Paystack is not configured.', [], 503);
        }
        $verifyUrl = rtrim($paystackApiUrl, '/') . '/transaction/verify/' . rawurlencode($reference);
        $ch = curl_init($verifyUrl);
        curl_setopt_array($ch, [
            CURLOPT_HTTPGET => true,
            CURLOPT_HTTPHEADER => ['Authorization: Bearer ' . $paystackSecretKey, 'Accept: application/json'],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 30,
        ]);
        $response = curl_exec($ch);
        if ($response === false) {
            $err = curl_error($ch);
            curl_close($ch);
            error_log('FastCheckerGH automatic Paystack verification cURL error: ' . $err);
            fc_auto_json(false, 'Unable to connect to Paystack.', [], 502);
        }
        $http = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        $paystack = json_decode($response, true);
        if ($http < 200 || $http >= 300 || !is_array($paystack) || empty($paystack['status'])) {
            $msg = is_array($paystack) ? ($paystack['message'] ?? 'Payment verification failed.') : 'Invalid response from Paystack.';
            fc_auto_json(false, $msg, [], 400);
        }
        $tx = $paystack['data'] ?? [];
        if (($tx['status'] ?? '') !== 'success') {
            fc_auto_json(false, 'Payment has not been completed.', ['payment_status' => $tx['status'] ?? ''], 400);
        }
        if ((int)($tx['amount'] ?? 0) !== $expected) {
            fc_auto_json(false, 'Payment amount does not match the order.', [], 400);
        }
        if (($tx['currency'] ?? '') !== $paystackCurrency) {
            fc_auto_json(false, 'Payment currency does not match the order.', [], 400);
        }
    }

    $pdo->beginTransaction();

    $stmt = $pdo->prepare("SELECT id, order_id, payment_reference, amount, status FROM payments WHERE payment_reference = ? AND order_id = ? FOR UPDATE");
    $stmt->execute([$reference, (int)$ctx['order_id']]);
    $payment = $stmt->fetch();
    if (!$payment) {
        throw new RuntimeException('Payment record not found for this automatic result order.');
    }

    $stmt = $pdo->prepare("SELECT id, voucher_id, status FROM result_requests WHERE id = ? AND order_id = ? FOR UPDATE");
    $stmt->execute([$requestId, (int)$ctx['order_id']]);
    $request = $stmt->fetch();
    if (!$request) {
        throw new RuntimeException('Automatic result request is not linked to this order.');
    }

    // Idempotent retry: if a voucher is already assigned, do not allocate another.
    if (!empty($request['voucher_id'])) {
        $stmt = $pdo->prepare("SELECT id, serial_number, pin FROM vouchers WHERE id = ? LIMIT 1");
        $stmt->execute([(int)$request['voucher_id']]);
        $voucher = $stmt->fetch();
        if ($voucher) {
            $pdo->commit();
            fc_auto_json(true, 'Payment verified and checker already assigned.', [
                'order_id'=>(int)$ctx['order_id'],
                'request_id'=>$requestId,
                'payment_reference'=>$reference,
                'payment_status'=>'successful',
                'order_status'=>'completed',
                'voucher'=>$voucher,
            ]);
        }
    }

    // Record the successful payment first, then fulfill the paid order.
    $stmt = $pdo->prepare("UPDATE payments SET status='successful', paid_at=NOW() WHERE id=?");
    $stmt->execute([(int)$payment['id']]);
    $stmt = $pdo->prepare("UPDATE orders SET status='paid' WHERE id=? AND status IN ('pending','paid')");
    $stmt->execute([(int)$ctx['order_id']]);

    $qty = max(1, (int)$ctx['quantity']);
    if ($qty !== 1) {
        throw new RuntimeException('Automatic result orders must contain exactly one checker.');
    }

    // Lock one available voucher for the exact product used by the order.
    $stmt = $pdo->prepare("SELECT id, serial_number, pin FROM vouchers WHERE product_id=? AND status='available' AND order_id IS NULL ORDER BY id ASC LIMIT 1 FOR UPDATE");
    $stmt->execute([(int)$ctx['product_id']]);
    $voucher = $stmt->fetch();

    if (!$voucher) {
        $stmt = $pdo->prepare("UPDATE result_requests SET status='awaiting_voucher', provider='automatic_purchase', error_message=?, processed_at=NULL WHERE id=?");
        $stmt->execute(['Payment verified. No available ' . $ctx['product_name'] . ' is currently in inventory. Upload checker cards in Admin > Upload Checker Cards, then retry assignment using the same payment reference.', $requestId]);
        $pdo->commit();
        fc_auto_json(false, 'Payment was verified, but no available ' . $ctx['product_name'] . ' voucher is currently in inventory. The payment has been recorded safely. Upload more checker cards, then retry this order.', [
            'payment_verified'=>true,
            'needs_voucher'=>true,
            'order_id'=>(int)$ctx['order_id'],
            'request_id'=>$requestId,
            'payment_reference'=>$reference,
            'product_name'=>$ctx['product_name'],
        ], 409);
    }

    $stmt = $pdo->prepare("UPDATE vouchers SET order_id=?, status='assigned' WHERE id=? AND status='available' AND order_id IS NULL");
    $stmt->execute([(int)$ctx['order_id'], (int)$voucher['id']]);
    if ($stmt->rowCount() !== 1) {
        throw new RuntimeException('The selected checker voucher was claimed by another order. Please retry the assignment.');
    }

    $stmt = $pdo->prepare("UPDATE orders SET status='completed' WHERE id=?");
    $stmt->execute([(int)$ctx['order_id']]);
    $stmt = $pdo->prepare("UPDATE result_requests SET voucher_id=?, status='verified', provider='automatic_purchase', error_message=NULL, processed_at=NOW() WHERE id=?");
    $stmt->execute([(int)$voucher['id'], $requestId]);

    $pdo->commit();

    fc_auto_json(true, 'Payment verified and checker assigned successfully.', [
        'payment_verified'=>true,
        'order_id'=>(int)$ctx['order_id'],
        'request_id'=>$requestId,
        'payment_reference'=>$reference,
        'payment_status'=>'successful',
        'order_status'=>'completed',
        'product_name'=>$ctx['product_name'],
        'voucher'=>$voucher,
    ]);

} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    error_log('FastCheckerGH automatic payment fulfillment error: ' . $e->getMessage());
    fc_auto_json(false, 'We could not complete the automatic checker assignment. Please try again.', ['debug_error'=>(getenv('FASTCHECKERGH_ENV') === 'local' ? $e->getMessage() : null)], 500);
}
