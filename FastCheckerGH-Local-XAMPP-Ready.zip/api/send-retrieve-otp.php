<?php
// FastCheckerGH - Retrieve Old Checkers: send OTP
// Uses PHP session storage for the short-lived OTP so retrieval does not depend on
// a separate checker_otps database table or CREATE TABLE permission.
ob_start();
ini_set('display_errors', '0');
error_reporting(E_ALL);

function retrieve_json(bool $success, string $message, array $data = [], int $status = 200): void {
    while (ob_get_level() > 0) { ob_end_clean(); }
    http_response_code($status);
    header('Content-Type: application/json; charset=UTF-8');
    echo json_encode(array_merge(['success'=>$success,'message'=>$message], $data), JSON_UNESCAPED_SLASHES);
    exit;
}

set_exception_handler(function(Throwable $e): void {
    error_log('FastCheckerGH retrieve OTP error: '.$e->getMessage().' in '.$e->getFile().':'.$e->getLine());
    retrieve_json(false, 'Server error while processing the request. Please try again.', [], 500);
});

register_shutdown_function(function(): void {
    $e = error_get_last();
    if ($e && in_array($e['type'], [E_ERROR,E_PARSE,E_CORE_ERROR,E_COMPILE_ERROR], true)) {
        error_log('FastCheckerGH retrieve OTP fatal: '.$e['message'].' in '.$e['file'].':'.$e['line']);
        while (ob_get_level() > 0) { ob_end_clean(); }
        http_response_code(500);
        header('Content-Type: application/json; charset=UTF-8');
        echo json_encode(['success'=>false,'message'=>'Server error while processing the request.']);
    }
});

require_once __DIR__.'/../includes/env.php';
require_once __DIR__.'/../includes/db.php';
require_once __DIR__.'/../includes/phone.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    retrieve_json(false, 'Method not allowed.', [], 405);
}

$data = json_decode(file_get_contents('php://input'), true);
if (!is_array($data)) {
    retrieve_json(false, 'Invalid request data.', [], 400);
}

$inputPhone = trim((string)($data['phone'] ?? ''));
$phone = fc_canonical_phone($inputPhone);
if ($phone === '') {
    retrieve_json(false, 'Please enter a valid Ghana mobile number.', [], 400);
}

$variants = fc_phone_variants($phone);
if (!$variants) {
    retrieve_json(false, 'Please enter a valid Ghana mobile number.', [], 400);
}

// Support older purchases that stored phone numbers with 0/233/+233 formats.
$digitVariants = [];
foreach ($variants as $v) {
    $d = preg_replace('/\D+/', '', $v);
    if ($d !== '') { $digitVariants[] = $d; }
}
$digitVariants = array_values(array_unique($digitVariants));
$conditions = [];
$params = [];
foreach ($digitVariants as $digits) {
    $conditions[] = "REPLACE(REPLACE(REPLACE(REPLACE(phone,'+',''),' ',''),'-',''),'(', '') = ?";
    $params[] = $digits;
}

// Also compare the last 9 digits, which covers old local 0XXXXXXXXX entries.
$canonicalDigits = preg_replace('/\D+/', '', $phone);
$last9 = substr($canonicalDigits, -9);
if ($last9 !== '') {
    $conditions[] = "RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(phone,'+',''),' ',''),'-',''),'(', ''), 9) = ?";
    $params[] = $last9;
}

// Prefer a user record that actually has paid/completed orders.
// Older FastCheckerGH purchases may have created duplicate user records
// with different phone formats (055..., 233..., +233...).
// Selecting only the newest user can therefore hide older paid checkers.
$sql = 'SELECT u.id, u.phone,
               COALESCE(SUM(CASE WHEN o.status IN (\'paid\', \'completed\') THEN 1 ELSE 0 END), 0) AS paid_orders
        FROM users u
        LEFT JOIN orders o ON o.user_id = u.id
        WHERE '.implode(' OR ', $conditions).'
        GROUP BY u.id, u.phone
        ORDER BY paid_orders DESC, u.id DESC
        LIMIT 1';
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$user = $stmt->fetch();

if (!$user) {
    retrieve_json(false, 'No purchase account was found for this number.', [], 404);
}

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

// Block OTP spam for 60 seconds.
$lastSent = (int)($_SESSION['retrieve_otp_sent_at'] ?? 0);
if ($lastSent > 0 && (time() - $lastSent) < 60) {
    $wait = 60 - (time() - $lastSent);
    retrieve_json(false, 'Please wait '.$wait.' seconds before requesting another OTP.', ['retry_after'=>$wait], 429);
}

$otp = str_pad((string)random_int(0, 999999), 6, '0', STR_PAD_LEFT);
$ttl = max(60, (int)(getenv('RETRIEVE_OTP_TTL') ?: 300));

$_SESSION['retrieve_otp_hash'] = password_hash($otp, PASSWORD_DEFAULT);
$_SESSION['retrieve_otp_phone'] = $phone;
$_SESSION['retrieve_otp_user_id'] = (int)$user['id'];
$_SESSION['retrieve_otp_expires'] = time() + $ttl;
$_SESSION['retrieve_otp_attempts'] = 0;
$_SESSION['retrieve_otp_sent_at'] = time();
unset($_SESSION['checker_retrieval_verified'], $_SESSION['checker_retrieval_user_id'], $_SESSION['checker_retrieval_phone'], $_SESSION['checker_retrieval_expires'], $_SESSION['checker_retrieval_time']);

$message = "Your FastCheckerGH verification code is {$otp}. It expires in 5 minutes.";
$devMode = strtolower((string)(getenv('FASTCHECKERGH_ENV') ?: 'local')) !== 'production';
$devOtpEnabled = in_array(strtolower((string)(getenv('RETRIEVE_DEV_OTP') ?: '1')), ['1','true','yes'], true);

$sent = false;
$brevoKey = trim((string)getenv('BREVO_API_KEY'));
$brevoSender = trim((string)(getenv('BREVO_SMS_SENDER') ?: 'FastCheckerGH'));

if ($brevoKey !== '' && function_exists('curl_init')) {
    $ch = curl_init('https://api.brevo.com/v3/transactionalSMS/send');
    $payload = json_encode([
        'sender' => $brevoSender,
        'recipient' => fc_phone_international_digits($phone),
        'content' => $message,
        'type' => 'transactional'
    ]);
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_HTTPHEADER => ['accept: application/json','api-key: '.$brevoKey,'content-type: application/json'],
        CURLOPT_POSTFIELDS => $payload,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 20,
        CURLOPT_CONNECTTIMEOUT => 10,
    ]);
    $body = curl_exec($ch);
    $err = curl_error($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    $sent = ($err === '' && $code >= 200 && $code < 300);
    if (!$sent) { error_log('FastCheckerGH Brevo retrieval SMS failed: '.($err !== '' ? $err : 'HTTP '.$code.' '.$body)); }
}

if ($sent) {
    retrieve_json(true, 'OTP sent successfully.', [
        'expires_in'=>$ttl,
        'masked_phone'=>substr($phone,0,4).'****'.substr($phone,-3)
    ]);
}

if ($devMode && $devOtpEnabled) {
    retrieve_json(true, 'Development OTP generated successfully.', [
        'development_otp'=>$otp,
        'expires_in'=>$ttl,
        'masked_phone'=>substr($phone,0,4).'****'.substr($phone,-3)
    ]);
}

// Production without an SMS provider: clear the OTP so it cannot be used.
unset($_SESSION['retrieve_otp_hash'], $_SESSION['retrieve_otp_phone'], $_SESSION['retrieve_otp_user_id'], $_SESSION['retrieve_otp_expires'], $_SESSION['retrieve_otp_attempts']);
retrieve_json(false, 'SMS delivery is not configured yet. Please configure the SMS provider.', [], 503);
