<?php
session_start();
unset(
    $_SESSION['checker_retrieval_verified'],
    $_SESSION['checker_retrieval_user_id'],
    $_SESSION['checker_retrieval_phone'],
    $_SESSION['checker_retrieval_time'],
    $_SESSION['checker_retrieval_expires']
);
header('Location: ../retrieve.php');
exit;
