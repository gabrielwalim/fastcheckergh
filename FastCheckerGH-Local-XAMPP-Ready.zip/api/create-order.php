<?php

// ==========================================
// FASTCHECKERGH
// CREATE ORDER API
// ==========================================

// ------------------------------------------
// Database connection
// ------------------------------------------

require_once "../includes/db.php";
require_once "../includes/phone.php";


// ------------------------------------------
// JSON response helper
// ------------------------------------------

function jsonResponse(
    bool $success,
    string $message,
    array $data = [],
    int $statusCode = 200
) {

    http_response_code($statusCode);

    header(
        "Content-Type: application/json; charset=UTF-8"
    );

    echo json_encode(
        array_merge(
            [
                "success" => $success,
                "message" => $message
            ],
            $data
        )
    );

    exit;
}


// ------------------------------------------
// Allow POST requests only
// ------------------------------------------

if ($_SERVER["REQUEST_METHOD"] !== "POST") {

    jsonResponse(
        false,
        "Method not allowed.",
        [],
        405
    );

}


// ------------------------------------------
// Read JSON request
// ------------------------------------------

$rawData = file_get_contents("php://input");

$data = json_decode(
    $rawData,
    true
);


// ------------------------------------------
// Validate JSON data
// ------------------------------------------

if (!is_array($data)) {

    jsonResponse(
        false,
        "Invalid request data.",
        [],
        400
    );

}


// ------------------------------------------
// Get product ID
// ------------------------------------------

$productId = isset($data["product_id"])
    ? (int) $data["product_id"]
    : 0;


// ------------------------------------------
// Get quantity
// ------------------------------------------

$quantity = isset($data["quantity"])
    ? (int) $data["quantity"]
    : 0;


// ------------------------------------------
// Get phone number
// ------------------------------------------

$phone = isset($data["phone"])
    ? fc_canonical_phone((string)$data["phone"])
    : "";


// ------------------------------------------
// Get email address
// ------------------------------------------

$email = isset($data["email"])
    ? trim($data["email"])
    : "";


// ------------------------------------------
// Validate product
// ------------------------------------------

if ($productId <= 0) {

    jsonResponse(
        false,
        "Invalid product.",
        [],
        400
    );

}


// ------------------------------------------
// Validate quantity
// ------------------------------------------

if ($quantity < 1 || $quantity > 10) {

    jsonResponse(
        false,
        "Quantity must be between 1 and 10.",
        [],
        400
    );

}


// ------------------------------------------
// Validate phone number
// ------------------------------------------

if ($phone === "") {

    jsonResponse(
        false,
        "Phone number is required.",
        [],
        400
    );

}


// ------------------------------------------
// Validate email address
// ------------------------------------------

if (
    $email === "" ||
    !filter_var($email, FILTER_VALIDATE_EMAIL)
) {

    jsonResponse(
        false,
        "A valid email address is required.",
        [],
        400
    );

}


// ------------------------------------------
// Find product
// ------------------------------------------

$stmt = $pdo->prepare("
    SELECT
        id,
        name,
        price
    FROM products
    WHERE id = ?
    AND status = 'active'
    LIMIT 1
");

$stmt->execute([
    $productId
]);

$product = $stmt->fetch();


// ------------------------------------------
// Make sure product exists
// ------------------------------------------

if (!$product) {

    jsonResponse(
        false,
        "Product not found.",
        [],
        404
    );

}


// ------------------------------------------
// Calculate total
// ------------------------------------------

// IMPORTANT:
// The price comes from the database.
// We do NOT trust the price sent by JavaScript.

$unitPrice = (float) $product["price"];

$totalAmount = $unitPrice * $quantity;


// ------------------------------------------
// Start database transaction
// ------------------------------------------

$pdo->beginTransaction();


// ------------------------------------------
// Create order
// ------------------------------------------

try {

    // --------------------------------------
    // Find existing customer
    // --------------------------------------

    $stmt = $pdo->prepare("
        SELECT id
        FROM users
        WHERE phone = ?
        LIMIT 1
    ");

    $stmt->execute([
        $phone
    ]);

    $user = $stmt->fetch();


    // --------------------------------------
    // Create customer if not found
    // --------------------------------------

    if ($user) {

        $userId = (int) $user["id"];


        // Update email if necessary
        $stmt = $pdo->prepare("
            UPDATE users
            SET email = ?
            WHERE id = ?
        ");

        $stmt->execute([
            $email,
            $userId
        ]);

    } else {

        $stmt = $pdo->prepare("
            INSERT INTO users
            (
                phone,
                email
            )
            VALUES
            (
                ?,
                ?
            )
        ");

        $stmt->execute([
            $phone,
            $email
        ]);

        $userId = (int) $pdo->lastInsertId();

    }


    // --------------------------------------
    // Create order
    // --------------------------------------

    $stmt = $pdo->prepare("
        INSERT INTO orders
        (
            user_id,
            total_amount,
            status
        )
        VALUES
        (
            ?,
            ?,
            'pending'
        )
    ");

    $stmt->execute([
        $userId,
        $totalAmount
    ]);

    $orderId = (int) $pdo->lastInsertId();


    // --------------------------------------
    // Calculate order subtotal
    // --------------------------------------

    $subtotal = $unitPrice * $quantity;


    // --------------------------------------
    // Create order item
    // --------------------------------------

    $stmt = $pdo->prepare("
        INSERT INTO order_items
        (
            order_id,
            product_id,
            quantity,
            unit_price,
            subtotal
        )
        VALUES
        (
            ?,
            ?,
            ?,
            ?,
            ?
        )
    ");

    $stmt->execute([
        $orderId,
        $productId,
        $quantity,
        $unitPrice,
        $subtotal
    ]);


    // --------------------------------------
    // Commit transaction
    // --------------------------------------

    $pdo->commit();


    // --------------------------------------
    // Send successful response
    // --------------------------------------

    jsonResponse(
        true,
        "Order created successfully.",
        [
            "order_id" => $orderId,
            "product" => $product["name"],
            "quantity" => $quantity,
            "unit_price" => number_format(
                $unitPrice,
                2
            ),
            "total" => number_format(
                $totalAmount,
                2
            )
        ],
        200
    );


} catch (Throwable $e) {

    // --------------------------------------
    // Roll back transaction if active
    // --------------------------------------

    if ($pdo->inTransaction()) {

        $pdo->rollBack();

    }


    // --------------------------------------
    // Return safe error
    // --------------------------------------

    error_log(
        "FastCheckerGH order error: " .
        $e->getMessage()
    );


    jsonResponse(
        false,
        "Unable to create order. Please try again.",
        [],
        500
    );

}