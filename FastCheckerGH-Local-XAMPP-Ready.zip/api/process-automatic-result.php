<?php
require_once __DIR__ . '/../includes/automatic-results-schema.php';
require_once __DIR__ . '/../includes/results-provider.php';
require_once __DIR__ . '/../includes/result-delivery.php';

function fc_process_json(bool $success, string $message, array $data=[], int $status=200): void { http_response_code($status); header('Content-Type: application/json; charset=UTF-8'); echo json_encode(array_merge(['success'=>$success,'message'=>$message],$data)); exit; }
$requestId = (int)($_POST['request_id'] ?? $_GET['request_id'] ?? 0);
if ($requestId <= 0) fc_process_json(false,'Invalid result request.',[],400);
try {
    $st=$pdo->prepare("SELECT rr.*, u.phone, u.email, v.serial_number, v.pin FROM result_requests rr LEFT JOIN users u ON u.id=rr.user_id LEFT JOIN vouchers v ON v.id=rr.voucher_id WHERE rr.id=? LIMIT 1");
    $st->execute([$requestId]); $request=$st->fetch();
    if (!$request) fc_process_json(false,'Result request not found.',[],404);
    if ($request['status']==='completed' && !empty($request['result_payload']) && !empty($request['result_access_token'])) {
        $url = rtrim((string)(getenv('FASTCHECKERGH_SITE_URL') ?: 'http://localhost/fastcheckergh'),'/').'/result-view.php?token='.$request['result_access_token'];
        fc_process_json(true,'Result already processed.', ['request_id'=>$requestId,'result_url'=>$url,'status'=>'completed'],200);
    }
    if (empty($request['voucher_id'])) fc_process_json(false,'Payment is complete but the checker has not been assigned yet.',[],409);
    if (fc_result_provider_mode() !== 'waec_api' || !fc_result_provider_configured()) {
        fc_process_json(false,'Authorized WAEC API access is not configured. Configure the WAEC RVS/API credentials before automatic retrieval can run.',['status'=>'provider_unavailable'],503);
    }
    $provider = fc_submit_to_waec_api([
        'exam_type'=>$request['result_type'],
        'exam_year'=>$request['exam_year'],
        'index_number'=>$request['index_number'],
        'date_of_birth'=>$request['date_of_birth'],
        'serial_number'=>$request['serial_number'],
        'pin'=>$request['pin'],
        'request_id'=>$requestId,
    ]);
    if (empty($provider['success'])) {
        $st=$pdo->prepare("UPDATE result_requests SET status='provider_error', provider='waec_api', error_message=?, updated_at=NOW() WHERE id=?");
        $st->execute([(string)($provider['message'] ?? 'Provider error'),$requestId]);
        fc_process_json(false,(string)($provider['message'] ?? 'The WAEC result provider could not return the result.'),['status'=>$provider['status'] ?? 'provider_error'],502);
    }
    $token = bin2hex(random_bytes(32));
    $stored = ['data'=>$provider['data'],'provider_reference'=>$provider['reference'] ?? null];
    $st=$pdo->prepare("UPDATE result_requests SET status='completed', provider='waec_api', provider_reference=?, result_payload=?, result_access_token=?, error_message=NULL, processed_at=NOW(), updated_at=NOW() WHERE id=?");
    $st->execute([$provider['reference'] ?? null,json_encode($stored,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),$token,$requestId]);
    $url = rtrim((string)(getenv('FASTCHECKERGH_SITE_URL') ?: 'http://localhost/fastcheckergh'),'/').'/result-view.php?token='.$token;
    $request['result_type']=$request['result_type'];
    $deliveries = fc_deliver_result($pdo,$request,$provider['data'],$url);
    fc_process_json(true,'Result retrieved and delivery attempts completed.',['status'=>'completed','request_id'=>$requestId,'result_url'=>$url,'delivery'=>$deliveries],200);
} catch(Throwable $e) {
    error_log('FastCheckerGH automatic result processing error: '.$e->getMessage());
    fc_process_json(false,'Automatic result processing failed.', ['debug_error'=>((getenv('FASTCHECKERGH_ENV')==='local')?$e->getMessage():null)],500);
}
