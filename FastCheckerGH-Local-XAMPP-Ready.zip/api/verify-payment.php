<?php

// ==========================================
// FASTCHECKERGH
// VERIFY PAYSTACK PAYMENT
// AND ASSIGN VOUCHERS
// ==========================================


// ------------------------------------------
// Database connection
// ------------------------------------------

require_once "../includes/db.php";


// ------------------------------------------
// Paystack configuration
// ------------------------------------------

require_once "../config/paystack.php";


// ------------------------------------------
// JSON response helper
// ------------------------------------------

function jsonResponse(
    bool $success,
    string $message,
    array $data = [],
    int $statusCode = 200
) {

    http_response_code($statusCode);

    header(
        "Content-Type: application/json; charset=UTF-8"
    );

    echo json_encode(
        array_merge(
            [
                "success" => $success,
                "message" => $message
            ],
            $data
        )
    );

    exit;
}


// ------------------------------------------
// Allow POST only
// ------------------------------------------

if ($_SERVER["REQUEST_METHOD"] !== "POST") {

    jsonResponse(
        false,
        "Method not allowed.",
        [],
        405
    );

}


// ------------------------------------------
// Read JSON request
// ------------------------------------------

$rawData = file_get_contents("php://input");

$data = json_decode(
    $rawData,
    true
);


// ------------------------------------------
// Validate JSON
// ------------------------------------------

if (!is_array($data)) {

    jsonResponse(
        false,
        "Invalid request data.",
        [],
        400
    );

}


// ------------------------------------------
// Get payment reference
// ------------------------------------------

$reference = isset($data["reference"])
    ? trim($data["reference"])
    : "";


// ------------------------------------------
// Validate reference
// ------------------------------------------

if ($reference === "") {

    jsonResponse(
        false,
        "Payment reference is required.",
        [],
        400
    );

}


// ==========================================
// FIND PAYMENT AND ORDER
// ==========================================

$stmt = $pdo->prepare("
    SELECT

        payments.id,
        payments.order_id,
        payments.payment_reference,
        payments.amount,
        payments.status,

        orders.total_amount,
        orders.status AS order_status

    FROM payments

    INNER JOIN orders
        ON payments.order_id = orders.id

    WHERE payments.payment_reference = ?

    LIMIT 1
");

$stmt->execute([
    $reference
]);

$payment = $stmt->fetch();


// ------------------------------------------
// Make sure payment exists
// ------------------------------------------

if (!$payment) {

    jsonResponse(
        false,
        "Payment record not found.",
        [],
        404
    );

}


// ==========================================
// EXPECTED PAYMENT AMOUNT
// ==========================================

$expectedAmount =
    (int) round(
        ((float) $payment["amount"]) * 100
    );


// ==========================================
// ASK PAYSTACK TO VERIFY TRANSACTION
// ==========================================

$verifyUrl =
    $paystackApiUrl .
    "/transaction/verify/" .
    rawurlencode($reference);


$ch = curl_init(
    $verifyUrl
);


curl_setopt(
    $ch,
    CURLOPT_HTTPGET,
    true
);


curl_setopt(
    $ch,
    CURLOPT_HTTPHEADER,
    [

        "Authorization: Bearer " .
        $paystackSecretKey,

        "Accept: application/json"

    ]
);


curl_setopt(
    $ch,
    CURLOPT_RETURNTRANSFER,
    true
);


curl_setopt(
    $ch,
    CURLOPT_TIMEOUT,
    30
);


// ------------------------------------------
// Execute request
// ------------------------------------------

$response = curl_exec($ch);


// ------------------------------------------
// Check connection error
// ------------------------------------------

if ($response === false) {

    $curlError =
        curl_error($ch);

    curl_close($ch);

    error_log(
        "FastCheckerGH Paystack verification error: " .
        $curlError
    );

    jsonResponse(
        false,
        "Unable to connect to payment service.",
        [],
        500
    );

}


$httpStatus =
    curl_getinfo(
        $ch,
        CURLINFO_HTTP_CODE
    );


curl_close($ch);


// ==========================================
// DECODE PAYSTACK RESPONSE
// ==========================================

$paystackResponse =
    json_decode(
        $response,
        true
    );


// ------------------------------------------
// Validate response
// ------------------------------------------

if (
    !is_array($paystackResponse) ||
    !isset($paystackResponse["status"])
) {

    error_log(
        "Invalid Paystack verification response: " .
        $response
    );

    jsonResponse(
        false,
        "Invalid response from payment service.",
        [],
        502
    );

}


// ------------------------------------------
// Check API response
// ------------------------------------------

if (
    $httpStatus < 200 ||
    $httpStatus >= 300 ||
    $paystackResponse["status"] !== true
) {

    $message =
        $paystackResponse["message"]
        ?? "Payment verification failed.";

    jsonResponse(
        false,
        $message,
        [],
        400
    );

}


// ==========================================
// GET TRANSACTION DATA
// ==========================================

$transaction =
    $paystackResponse["data"]
    ?? null;


if (!is_array($transaction)) {

    jsonResponse(
        false,
        "Transaction information was not returned.",
        [],
        502
    );

}


// ==========================================
// CHECK TRANSACTION STATUS
// ==========================================

$transactionStatus =
    $transaction["status"]
    ?? "";


// ------------------------------------------
// Payment not successful
// ------------------------------------------

if ($transactionStatus !== "success") {

    jsonResponse(
        false,
        "Payment has not been completed.",
        [
            "payment_status" =>
                $transactionStatus
        ],
        400
    );

}


// ==========================================
// CHECK TRANSACTION AMOUNT
// ==========================================

$paidAmount =
    isset($transaction["amount"])
        ? (int) $transaction["amount"]
        : 0;


if ($paidAmount !== $expectedAmount) {

    error_log(
        "FastCheckerGH amount mismatch. " .
        "Expected: " .
        $expectedAmount .
        " Paid: " .
        $paidAmount
    );

    jsonResponse(
        false,
        "Payment amount does not match the order.",
        [],
        400
    );

}


// ==========================================
// CHECK CURRENCY
// ==========================================

$paidCurrency =
    $transaction["currency"]
    ?? "";


if ($paidCurrency !== $paystackCurrency) {

    error_log(
        "FastCheckerGH currency mismatch. " .
        "Expected: " .
        $paystackCurrency .
        " Paid: " .
        $paidCurrency
    );

    jsonResponse(
        false,
        "Payment currency does not match the order.",
        [],
        400
    );

}


// ==========================================
// START DATABASE TRANSACTION
// ==========================================

$pdo->beginTransaction();


try {

    // ======================================
    // LOCK PAYMENT RECORD
    // ======================================

    $stmt = $pdo->prepare("
        SELECT
            id,
            order_id,
            status
        FROM payments
        WHERE id = ?
        FOR UPDATE
    ");

    $stmt->execute([
        $payment["id"]
    ]);

    $lockedPayment =
        $stmt->fetch();


    if (!$lockedPayment) {

        throw new RuntimeException(
            "Payment record disappeared."
        );

    }


    // ======================================
    // GET ORDER ITEM
    // ======================================

    $stmt = $pdo->prepare("
        SELECT
            order_items.product_id,
            order_items.quantity,
            order_items.unit_price,
            products.name AS product_name

        FROM order_items

        INNER JOIN products
            ON order_items.product_id =
               products.id

        WHERE order_items.order_id = ?

        LIMIT 1
    ");

    $stmt->execute([
        $lockedPayment["order_id"]
    ]);

    $orderItem =
        $stmt->fetch();


    if (!$orderItem) {

        throw new RuntimeException(
            "Order item not found."
        );

    }


    $productId =
        (int) $orderItem["product_id"];

    $quantity =
        (int) $orderItem["quantity"];

    $productName =
        $orderItem["product_name"];


    // ======================================
    // CHECK QUANTITY
    // ======================================

    if ($quantity < 1) {

        throw new RuntimeException(
            "Invalid order quantity."
        );

    }


    // ======================================
    // CHECK IF PAYMENT WAS ALREADY
    // VERIFIED AND VOUCHERS ASSIGNED
    // ======================================

    if (
        $lockedPayment["status"]
        === "successful"
    ) {

        // ----------------------------------
        // Get vouchers already assigned
        // to this order
        // ----------------------------------

        $stmt = $pdo->prepare("
            SELECT
                id,
                serial_number,
                pin
            FROM vouchers
            WHERE order_id = ?
            AND product_id = ?
            AND status = 'assigned'
            ORDER BY id ASC
        ");

        $stmt->execute([
            $lockedPayment["order_id"],
            $productId
        ]);

        $existingVouchers =
            $stmt->fetchAll();


        // ----------------------------------
        // If vouchers already exist,
        // return them
        // ----------------------------------

        if (
            count($existingVouchers)
            >= $quantity
        ) {

            $pdo->commit();

            jsonResponse(
                true,
                "Payment has already been verified and vouchers assigned.",
                [

                    "order_id" =>
                        (int) $lockedPayment["order_id"],

                    "payment_reference" =>
                        $reference,

                    "payment_status" =>
                        "successful",

                    "order_status" =>
                        "completed",

                    "product_name" =>
                        $productName,

                    "quantity" =>
                        $quantity,

                    "vouchers" =>
                        $existingVouchers

                ],
                200
            );

        }

    }


    // ======================================
    // FIND AVAILABLE VOUCHERS
    // ======================================

    $stmt = $pdo->prepare("
        SELECT
            id,
            serial_number,
            pin

        FROM vouchers

        WHERE product_id = ?

        AND status = 'available'

        AND order_id IS NULL

        ORDER BY id ASC

        LIMIT " . $quantity . "

        FOR UPDATE
    ");

    $stmt->execute([
        $productId
    ]);

    $availableVouchers =
        $stmt->fetchAll();


    // ======================================
    // CHECK INVENTORY
    // ======================================

    if (
        count($availableVouchers)
        < $quantity
    ) {

        throw new RuntimeException(
            "Not enough vouchers available for this product."
        );

    }


    // ======================================
    // UPDATE PAYMENT
    // ======================================

    $stmt = $pdo->prepare("
        UPDATE payments

        SET
            status = 'successful',
            paid_at = NOW()

        WHERE id = ?
    ");

    $stmt->execute([
        $lockedPayment["id"]
    ]);


    // ======================================
    // UPDATE ORDER TO PAID
    // ======================================

    $stmt = $pdo->prepare("
        UPDATE orders

        SET
            status = 'paid'

        WHERE id = ?

        AND status = 'pending'
    ");

    $stmt->execute([
        $lockedPayment["order_id"]
    ]);


    // ======================================
    // ASSIGN VOUCHERS
    // ======================================

    $assignedVouchers = [];


    $stmt = $pdo->prepare("
        UPDATE vouchers

        SET
            order_id = ?,
            status = 'assigned'

        WHERE id = ?
        AND status = 'available'
        AND order_id IS NULL
    ");


    foreach (
        $availableVouchers
        as $voucher
    ) {

        $stmt->execute([

            $lockedPayment["order_id"],

            $voucher["id"]

        ]);


        if ($stmt->rowCount() !== 1) {

            throw new RuntimeException(
                "Unable to assign voucher."
            );

        }


        $assignedVouchers[] = [

            "id" =>
                (int) $voucher["id"],

            "serial_number" =>
                $voucher["serial_number"],

            "pin" =>
                $voucher["pin"]

        ];

    }


    // ======================================
    // UPDATE ORDER TO COMPLETED
    // ======================================

    $stmt = $pdo->prepare("
        UPDATE orders

        SET
            status = 'completed'

        WHERE id = ?
    ");

    $stmt->execute([
        $lockedPayment["order_id"]
    ]);


    // ======================================
    // COMMIT EVERYTHING
    // ======================================

    $pdo->commit();


    // ======================================
    // RETURN SUCCESS
    // ======================================

    jsonResponse(
        true,
        "Payment verified and vouchers assigned successfully.",
        [

            "order_id" =>
                (int) $lockedPayment["order_id"],

            "payment_reference" =>
                $reference,

            "payment_status" =>
                "successful",

            "order_status" =>
                "completed",

            "product_name" =>
                $productName,

            "quantity" =>
                $quantity,

            "vouchers" =>
                $assignedVouchers

        ],
        200
    );


} catch (Throwable $e) {

    // ======================================
    // ROLLBACK
    // ======================================

    if ($pdo->inTransaction()) {

        $pdo->rollBack();

    }


    // ======================================
    // LOG ERROR
    // ======================================

    error_log(
        "FastCheckerGH verification/fulfillment error: " .
        $e->getMessage()
    );


    jsonResponse(
        false,
        "Payment was verified, but we could not assign the checker voucher. Please contact support.",
        [],
        500
    );

}