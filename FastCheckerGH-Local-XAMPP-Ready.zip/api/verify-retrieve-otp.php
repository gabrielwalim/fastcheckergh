<?php
// FastCheckerGH - Retrieve Old Checkers: verify OTP
ob_start();
ini_set('display_errors', '0');
error_reporting(E_ALL);

function retrieve_verify_json(bool $success, string $message, array $data = [], int $status = 200): void {
    while (ob_get_level() > 0) { ob_end_clean(); }
    http_response_code($status);
    header('Content-Type: application/json; charset=UTF-8');
    echo json_encode(array_merge(['success'=>$success,'message'=>$message], $data), JSON_UNESCAPED_SLASHES);
    exit;
}

set_exception_handler(function(Throwable $e): void {
    error_log('FastCheckerGH verify retrieve OTP error: '.$e->getMessage().' in '.$e->getFile().':'.$e->getLine());
    retrieve_verify_json(false, 'Server error while verifying the OTP. Please try again.', [], 500);
});

register_shutdown_function(function(): void {
    $e = error_get_last();
    if ($e && in_array($e['type'], [E_ERROR,E_PARSE,E_CORE_ERROR,E_COMPILE_ERROR], true)) {
        error_log('FastCheckerGH verify retrieve OTP fatal: '.$e['message'].' in '.$e['file'].':'.$e['line']);
        while (ob_get_level() > 0) { ob_end_clean(); }
        http_response_code(500);
        header('Content-Type: application/json; charset=UTF-8');
        echo json_encode(['success'=>false,'message'=>'Server error while verifying the OTP.']);
    }
});

require_once __DIR__.'/../includes/env.php';
require_once __DIR__.'/../includes/db.php';
require_once __DIR__.'/../includes/phone.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    retrieve_verify_json(false, 'Method not allowed.', [], 405);
}

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

$data = json_decode(file_get_contents('php://input'), true);
if (!is_array($data)) {
    retrieve_verify_json(false, 'Invalid request data.', [], 400);
}

$phone = fc_canonical_phone((string)($data['phone'] ?? ''));
$otp = trim((string)($data['otp'] ?? ''));
if ($phone === '') { retrieve_verify_json(false, 'Phone number is required.', [], 400); }
if (!preg_match('/^[0-9]{6}$/', $otp)) { retrieve_verify_json(false, 'Please enter the 6-digit OTP.', [], 400); }

$storedPhone = (string)($_SESSION['retrieve_otp_phone'] ?? '');
$hash = (string)($_SESSION['retrieve_otp_hash'] ?? '');
$userId = (int)($_SESSION['retrieve_otp_user_id'] ?? 0);
$expires = (int)($_SESSION['retrieve_otp_expires'] ?? 0);
$attempts = (int)($_SESSION['retrieve_otp_attempts'] ?? 0);

if ($storedPhone === '' || $hash === '' || $userId <= 0 || $expires <= 0) {
    retrieve_verify_json(false, 'OTP not found. Please request a new OTP.', [], 404);
}
if (!hash_equals($storedPhone, $phone)) {
    retrieve_verify_json(false, 'The phone number does not match the OTP request.', [], 400);
}
if ($attempts >= 5) {
    retrieve_verify_json(false, 'Too many incorrect attempts. Please request a new OTP.', [], 429);
}
if (time() > $expires) {
    unset($_SESSION['retrieve_otp_hash'], $_SESSION['retrieve_otp_phone'], $_SESSION['retrieve_otp_user_id'], $_SESSION['retrieve_otp_expires'], $_SESSION['retrieve_otp_attempts']);
    retrieve_verify_json(false, 'This OTP has expired. Please request a new OTP.', [], 400);
}
if (!password_verify($otp, $hash)) {
    $_SESSION['retrieve_otp_attempts'] = $attempts + 1;
    retrieve_verify_json(false, 'Incorrect OTP.', ['remaining_attempts'=>max(0,5-($attempts+1))], 400);
}

$stmt = $pdo->prepare('SELECT id, phone FROM users WHERE id = ? LIMIT 1');
$stmt->execute([$userId]);
$user = $stmt->fetch();
if (!$user) {
    retrieve_verify_json(false, 'Purchase account not found.', [], 404);
}

// Consume OTP and create a short-lived retrieval session.
unset($_SESSION['retrieve_otp_hash'], $_SESSION['retrieve_otp_phone'], $_SESSION['retrieve_otp_user_id'], $_SESSION['retrieve_otp_expires'], $_SESSION['retrieve_otp_attempts'], $_SESSION['retrieve_otp_sent_at']);
$_SESSION['checker_retrieval_verified'] = true;
$_SESSION['checker_retrieval_user_id'] = (int)$user['id'];
$_SESSION['checker_retrieval_phone'] = (string)$user['phone'];
$_SESSION['checker_retrieval_time'] = time();
$_SESSION['checker_retrieval_expires'] = time() + 1200;

retrieve_verify_json(true, 'OTP verified successfully.', ['verified'=>true]);
