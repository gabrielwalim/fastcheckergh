<?php

// ==========================================
// FASTCHECKERGH
// INITIALIZE PAYSTACK PAYMENT
// ==========================================

require_once "../includes/db.php";
require_once "../config/paystack.php";


// ==========================================
// JSON RESPONSE HELPER
// ==========================================

function jsonResponse(
    bool $success,
    string $message,
    array $data = [],
    int $statusCode = 200
) {

    http_response_code($statusCode);

    header(
        "Content-Type: application/json; charset=UTF-8"
    );

    echo json_encode(
        array_merge(
            [
                "success" => $success,
                "message" => $message
            ],
            $data
        )
    );

    exit;
}


// ==========================================
// ONLY ALLOW POST
// ==========================================

if ($_SERVER["REQUEST_METHOD"] !== "POST") {

    jsonResponse(
        false,
        "Method not allowed.",
        [],
        405
    );
}


// ==========================================
// READ REQUEST
// ==========================================

$rawData =
    file_get_contents("php://input");

$data =
    json_decode(
        $rawData,
        true
    );


// ==========================================
// VALIDATE REQUEST
// ==========================================

if (!is_array($data)) {

    jsonResponse(
        false,
        "Invalid request data.",
        [],
        400
    );
}


// ==========================================
// GET ORDER ID
// ==========================================

$orderId =
    isset($data["order_id"])
        ? (int)$data["order_id"]
        : 0;


if ($orderId <= 0) {

    jsonResponse(
        false,
        "Invalid order ID.",
        [],
        400
    );
}


// ==========================================
// GET ORDER
// ==========================================

$stmt = $pdo->prepare("
    SELECT
        orders.id,
        orders.total_amount,
        orders.status,
        users.email
    FROM orders

    INNER JOIN users
        ON orders.user_id = users.id

    WHERE orders.id = ?

    AND orders.status = 'pending'

    LIMIT 1
");

$stmt->execute([
    $orderId
]);

$order =
    $stmt->fetch();


// ==========================================
// CHECK ORDER
// ==========================================

if (!$order) {

    jsonResponse(
        false,
        "Order not found or is no longer pending.",
        [],
        404
    );
}


// ==========================================
// GET AMOUNT
// ==========================================

$totalAmount =
    (float)$order["total_amount"];


if ($totalAmount <= 0) {

    jsonResponse(
        false,
        "Invalid order amount.",
        [],
        400
    );
}


// ==========================================
// CONVERT GHS TO PESEWAS
// ==========================================

$amountInPesewas =
    (int)round(
        $totalAmount * 100
    );


// ==========================================
// CREATE UNIQUE REFERENCE
// ==========================================

$reference =
    "FCGH-" .
    $orderId .
    "-" .
    strtoupper(
        bin2hex(
            random_bytes(5)
        )
    );


// ==========================================
// PAYSTACK REQUEST
// ==========================================

$payload = [

    "email" =>
        $order["email"],

    "amount" =>
        (string)$amountInPesewas,

    "currency" =>
        $paystackCurrency,

    "reference" =>
        $reference,

    "callback_url" =>
        $paymentCallbackUrl,

    "channels" => [
        "card",
        "mobile_money"
    ],

    "metadata" => [

        "order_id" =>
            $orderId,

        "source" =>
            "FastCheckerGH"
    ]
];


// ==========================================
// CONNECT TO PAYSTACK
// ==========================================

$ch = curl_init(
    $paystackApiUrl .
    "/transaction/initialize"
);


curl_setopt_array(
    $ch,
    [

        CURLOPT_POST =>
            true,

        CURLOPT_POSTFIELDS =>
            json_encode($payload),

        CURLOPT_HTTPHEADER => [

            "Authorization: Bearer " .
            $paystackSecretKey,

            "Content-Type: application/json",

            "Accept: application/json"
        ],

        CURLOPT_RETURNTRANSFER =>
            true,

        CURLOPT_TIMEOUT =>
            30
    ]
);


// ==========================================
// SEND REQUEST
// ==========================================

$response =
    curl_exec($ch);


// ==========================================
// CHECK CURL
// ==========================================

if ($response === false) {

    $curlError =
        curl_error($ch);

    curl_close($ch);

    error_log(
        "FastCheckerGH Paystack cURL error: " .
        $curlError
    );

    jsonResponse(
        false,
        "Unable to connect to Paystack: " .
        $curlError,
        [],
        500
    );
}


// ==========================================
// GET HTTP STATUS
// ==========================================

$httpStatus =
    curl_getinfo(
        $ch,
        CURLINFO_HTTP_CODE
    );

curl_close($ch);


// ==========================================
// DECODE RESPONSE
// ==========================================

$paystackResponse =
    json_decode(
        $response,
        true
    );


// ==========================================
// CHECK RESPONSE
// ==========================================

if (!is_array($paystackResponse)) {

    error_log(
        "FastCheckerGH invalid Paystack response: " .
        $response
    );

    jsonResponse(
        false,
        "Invalid response from Paystack.",
        [
            "http_status" =>
                $httpStatus
        ],
        502
    );
}


// ==========================================
// CHECK PAYSTACK STATUS
// ==========================================

if (
    $httpStatus < 200 ||
    $httpStatus >= 300 ||
    !isset($paystackResponse["status"]) ||
    $paystackResponse["status"] !== true
) {

    $errorMessage =
        $paystackResponse["message"]
        ?? "Paystack could not initialize the payment.";

    error_log(
        "FastCheckerGH Paystack error: " .
        $response
    );

    jsonResponse(
        false,
        $errorMessage,
        [
            "http_status" =>
                $httpStatus
        ],
        502
    );
}


// ==========================================
// GET PAYMENT DATA
// ==========================================

if (
    !isset(
        $paystackResponse["data"],
        $paystackResponse["data"]["authorization_url"],
        $paystackResponse["data"]["reference"]
    )
) {

    error_log(
        "FastCheckerGH missing Paystack payment data: " .
        $response
    );

    jsonResponse(
        false,
        "Paystack did not return a payment URL.",
        [],
        502
    );
}


// ==========================================
// SAVE PAYMENT
// ==========================================

try {

    $stmt =
        $pdo->prepare("
            INSERT INTO payments
            (
                order_id,
                payment_reference,
                amount,
                method,
                status
            )
            VALUES
            (
                ?,
                ?,
                ?,
                ?,
                'pending'
            )
        ");

    $stmt->execute([

        $orderId,

        $paystackResponse["data"]["reference"],

        $totalAmount,

        "paystack"
    ]);

} catch (Throwable $e) {

    error_log(
        "FastCheckerGH payment record error: " .
        $e->getMessage()
    );

    jsonResponse(
        false,
        "Unable to save payment information.",
        [],
        500
    );
}


// ==========================================
// RETURN PAYMENT URL
// ==========================================

jsonResponse(

    true,

    "Payment initialized successfully.",

    [

        "order_id" =>
            $orderId,

        "reference" =>
            $paystackResponse["data"]["reference"],

        "authorization_url" =>
            $paystackResponse["data"]["authorization_url"]
    ],

    200
);