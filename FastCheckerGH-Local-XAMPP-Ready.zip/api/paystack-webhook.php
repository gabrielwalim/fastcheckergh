<?php
// FastCheckerGH - Paystack webhook endpoint.
// Verifies Paystack's x-paystack-signature and synchronizes payment/order state.
require_once __DIR__ . '/../includes/env.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../config/paystack.php';

header('Content-Type: application/json; charset=UTF-8');

function fc_webhook_json(bool $ok, string $message, array $data = [], int $code = 200): void
{
    http_response_code($code);
    echo json_encode(array_merge(['success' => $ok, 'message' => $message], $data), JSON_UNESCAPED_SLASHES);
    exit;
}

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    fc_webhook_json(false, 'Method not allowed.', [], 405);
}

$secret = trim((string)$paystackSecretKey);
if ($secret === '') {
    error_log('FastCheckerGH Paystack webhook rejected: secret key is not configured.');
    fc_webhook_json(false, 'Webhook is not configured.', [], 503);
}

$raw = (string)file_get_contents('php://input');
$signature = (string)($_SERVER['HTTP_X_PAYSTACK_SIGNATURE'] ?? '');
$expected = hash_hmac('sha512', $raw, $secret);
if ($signature === '' || !hash_equals($expected, $signature)) {
    error_log('FastCheckerGH Paystack webhook rejected: invalid signature.');
    fc_webhook_json(false, 'Invalid signature.', [], 401);
}

$payload = json_decode($raw, true);
if (!is_array($payload)) {
    fc_webhook_json(false, 'Invalid JSON payload.', [], 400);
}

try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS paystack_webhook_events (\n        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,\n        event_hash CHAR(64) NOT NULL,\n        event_name VARCHAR(120) NULL,\n        reference VARCHAR(191) NULL,\n        payload LONGTEXT NOT NULL,\n        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,\n        PRIMARY KEY (id),\n        UNIQUE KEY uq_paystack_webhook_hash (event_hash),\n        KEY idx_paystack_webhook_reference (reference),\n        KEY idx_paystack_webhook_created (created_at)\n    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $eventHash = hash('sha256', $raw);
    $eventName = trim((string)($payload['event'] ?? ''));
    $reference = trim((string)($payload['data']['reference'] ?? ''));

    $insert = $pdo->prepare('INSERT IGNORE INTO paystack_webhook_events (event_hash, event_name, reference, payload) VALUES (?, ?, ?, ?)');
    $insert->execute([$eventHash, $eventName ?: null, $reference ?: null, $raw]);

    if ($insert->rowCount() === 0) {
        fc_webhook_json(true, 'Webhook already processed.');
    }

    if ($eventName === 'charge.success' && $reference !== '') {
        $amount = (int)($payload['data']['amount'] ?? 0);
        $currency = (string)($payload['data']['currency'] ?? '');
        $transactionStatus = (string)($payload['data']['status'] ?? '');

        if ($transactionStatus === 'success') {
            $stmt = $pdo->prepare('SELECT id, order_id, amount, status FROM payments WHERE payment_reference = ? LIMIT 1');
            $stmt->execute([$reference]);
            $payment = $stmt->fetch();

            if ($payment) {
                $expected = (int)round((float)$payment['amount'] * 100);
                if ($amount === $expected && $currency === $paystackCurrency) {
                    $pdo->beginTransaction();
                    $stmt = $pdo->prepare("UPDATE payments SET status='successful', paid_at=NOW() WHERE id=?");
                    $stmt->execute([(int)$payment['id']]);
                    $stmt = $pdo->prepare("UPDATE orders SET status=CASE WHEN status='completed' THEN status ELSE 'paid' END WHERE id=?");
                    $stmt->execute([(int)$payment['order_id']]);
                    $pdo->commit();
                } else {
                    error_log('FastCheckerGH Paystack webhook amount/currency mismatch for reference ' . $reference);
                }
            }
        }
    }

    fc_webhook_json(true, 'Webhook received.');
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log('FastCheckerGH Paystack webhook error: ' . $e->getMessage());
    fc_webhook_json(false, 'Webhook processing failed.', [], 500);
}
